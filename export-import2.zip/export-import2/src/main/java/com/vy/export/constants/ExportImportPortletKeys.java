package com.vy.export.constants;

/**
 * @author vidyayug
 */
public class ExportImportPortletKeys {

	public static final String EXPORTIMPORT =
		"com_vy_export_ExportImportPortlet";

}