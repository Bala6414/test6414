package com.vy.export.portlet;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ExportImportProperties {
	
  static   String jsonString = "{"
            + "\"_portlet_display_template_Blogs Template\": [\"true\"],"
            + "\"PERMISSIONS\": [\"false\"],"
            + "\"endDate\": [\"10/16/2024\"],"
            + "\"_journal_web-content\": [\"true\"],"
            + "\"groupId\": [\"53536833\"],"
            + "\"_journal_templates\": [\"true\"],"
            + "\"LOGO\": [\"true\"],"
            + "\"_page-templates_page-template-collectionsDisplay\": [\"false\"],"
            + "\"PORTLET_DATA_com_liferay_site_teams_web_portlet_SiteTeamsPortlet\": [\"false\"],"
            + "\"mvcRenderCommandName\": [\"exportLayouts\"],"
            + "\"_site_teams_teamsDisplay\": [\"false\"],"
            + "\"_forms_form-entries\": [\"true\"],"
            + "\"checkboxNames\": [\"DELETIONS,THEME_REFERENCE,LOGO,LAYOUT_SET_SETTINGS,LAYOUT_SET_PROTOTYPE_SETTINGS,"
            + "PORTLET_DATA_com_liferay_site_teams_web_portlet_SiteTeamsPortlet,_site_teams_teamsDisplay,"
            + "PORTLET_DATA_com_liferay_document_library_web_portlet_DLAdminPortlet,_document_library_documents,"
            + "_document_library_previews-and-thumbnails,PORTLET_DATA_com_liferay_journal_web_portlet_JournalPortlet,"
            + "_journal_web-content,_journal_referenced-content,_journal_version-history,_journal_structures,"
            + "_journal_templates,PORTLET_DATA_com_liferay_dynamic_data_mapping_form_web_portlet_DDMFormAdminPortlet,"
            + "_forms_forms,_forms_form-entries,PORTLET_DATA_com_liferay_layout_admin_web_portlet_GroupPagesPortlet,"
            + "_page-templates_page-template-collectionsDisplay,_page-templates_page-templates,"
            + "PORTLET_DATA_com_liferay_fragment_web_portlet_FragmentPortlet,_fragments_entries,"
            + "PORTLET_DATA_com_liferay_site_navigation_admin_web_portlet_SiteNavigationAdminPortlet,"
            + "_navigation-menus_navigation-menus,PORTLET_DATA_com_liferay_dynamic_data_mapping_web_portlet_"
            + "PortletDisplayTemplatePortlet,_portlet_display_template_application-display-templatesDisplay,"
            + "_portlet_display_template_Blogs Template,PORTLET_DATA_com_liferay_asset_list_web_portlet_AssetListPortlet,"
            + "_asset_lists_entries,PORTLET_DATA_com_liferay_calendar_web_portlet_CalendarAdminPortlet,"
            + "_calendar_calendars,_calendar_calendar-resources,COMMENTS,RATINGS,PERMISSIONS\"],"
            + "\"_portlet_display_template_application-display-templatesDisplay\": [\"false\"],"
            + "\"_journal_referenced-content-behavior\": [\"include-always\"],"
            + "\"endDateMinute\": [\"17\"],"
            + "\"endDateHour\": [\"3\"],"
            + "\"LAYOUT_SET_SETTINGS\": [\"true\"],"
            + "\"javax.portlet.action\": [\"exportLayouts\"],"
            + "\"endDateAmPm\": [\"1\"],"
            + "\"PORTLET_DATA_com_liferay_journal_web_portlet_JournalPortlet\": [\"false\"],"
            + "\"last\": [\"12\"],"
            + "\"endDateDay\": [\"16\"],"
            + "\"formDate\": [\"1729091829125\"],"
            + "\"_page-templates_page-template-collections\": [\"true\"],"
            + "\"PORTLET_DATA_CONTROL_DEFAULT\": [\"true\"],"
            + "\"privateLayout\": [\"false\"],"
            + "\"endDateTime\": [\"Wed Oct 16 15:17:09 GMT 2024\"],"
            + "\"_portlet_display_template_application-display-templates\": [\"true\"],"
            + "\"PORTLET_DATA_com_liferay_asset_list_web_portlet_AssetListPortlet\": [\"false\"],"
            + "\"treeId\": [\"layoutsExportTree53536833false\"],"
            + "\"PORTLET_DATA_com_liferay_site_navigation_admin_web_portlet_SiteNavigationAdminPortlet\": [\"false\"],"
            + "\"PORTLET_DATA_com_liferay_calendar_web_portlet_CalendarAdminPortlet\": [\"false\"],"
            + "\"name\": [\"My pages\"],"
            + "\"RATINGS\": [\"true\"],"
            + "\"endDateYear\": [\"2024\"],"
            + "\"cmd\": [\"export\"],"
            + "\"PORTLET_SETUP_ALL\": [\"true\"],"
            + "\"startDateMonth\": [\"9\"],"
            + "\"layoutIds\": [\"[{\\\"plid\\\":\\\"1595915\\\",\\\"includeChildren\\\":true},"
            + "{\\\"plid\\\":\\\"1596019\\\",\\\"includeChildren\\\":true},{\\\"plid\\\":\\\"1596021\\\","
            + "\\\"includeChildren\\\":true},{\\\"plid\\\":\\\"1596022\\\",\\\"includeChildren\\\":true},"
            + "{\\\"plid\\\":0,\\\"includeChildren\\\":true}]\"],"
            + "\"startDate\": [\"10/15/2024\"],"
            + "\"_navigation-menus_navigation-menus\": [\"true\"],"
            + "\"startDateMinute\": [\"17\"],"
            + "\"PORTLET_DATA\": [\"true\"],"
            + "\"PORTLET_DATA_com_liferay_dynamic_data_mapping_form_web_portlet_DDMFormAdminPortlet\": [\"false\"],"
            + "\"_page-templates_page-templates\": [\"true\"],"
            + "\"rootNodeName\": [\"Public Pages\"],"
            + "\"COMMENTS\": [\"true\"],"
            + "\"range\": [\"all\"],"
            + "\"_asset_lists_entries\": [\"true\"],"
            + "\"startDateDay\": [\"15\"],"
            + "\"_calendar_calendars\": [\"true\"],"
            + "\"PORTLET_DATA_com_liferay_fragment_web_portlet_FragmentPortlet\": [\"false\"],"
            + "\"PORTLET_DATA_com_liferay_layout_admin_web_portlet_GroupPagesPortlet\": [\"false\"],"
            + "\"PORTLET_ARCHIVED_SETUPS_ALL\": [\"true\"],"
            + "\"PORTLET_DATA_com_liferay_dynamic_data_mapping_web_portlet_PortletDisplayTemplatePortlet\": [\"false\"],"
            + "\"PORTLET_CONFIGURATION_ALL\": [\"true\"],"
            + "\"startTime\": [\"03:17 PM\"],"
            + "\"liveGroupId\": [\"53536833\"],"
            + "\"exportImportConfigurationId\": [\"0\"],"
            + "\"_document_library_documents\": [\"true\"],"
            + "\"startDateHour\": [\"3\"],"
            + "\"_journal_version-history\": [\"true\"],"
            + "\"redirect\": [\"https://localomt.gvclearn.com/group/localomt/~/control_panel/manage?"
            + "p_p_id=com_liferay_exportimport_web_portlet_ExportPortlet&p_p_lifecycle=0&p_p_state=maximized&p_p_mode=view"
            + "&_com_liferay_exportimport_web_portlet_ExportPortlet_mvcRenderCommandName=exportLayoutsView"
            + "&_com_liferay_exportimport_web_portlet_ExportPortlet_groupId=53536833&_com_liferay_exportimport_web_portlet_"
            + "ExportPortlet_liveGroupId=53536833&_com_liferay_exportimport_web_portlet_ExportPortlet_privateLayout=false"
            + "&_com_liferay_exportimport_web_portlet_ExportPortlet_displayStyle=&p_p_auth=eqIAr5rd\"],"
            + "\"THEME_REFERENCE\": [\"true\"],"
            + "\"exportLAR\": [\"true\"],"
            + "\"_journal_referenced-content\": [\"true\"],"
            + "\"_calendar_calendar-resources\": [\"true\"],"
            + "\"_document_library_previews-and-thumbnails\": [\"true\"],"
            + "\"startDateTime\": [\"Tue Oct 15 15:17:09 GMT 2024\"],"
            + "\"_fragments_entries\": [\"true\"],"
            + "\"_journal_structures\": [\"true\"],"
            + "\"_forms_forms\": [\"true\"],"
            + "\"PORTLET_USER_PREFERENCES_ALL\": [\"true\"],"
            + "\"endTime\": [\"03:17 PM\"],"
            + "\"_site_teams_teams\": [\"true\"],"
            + "\"startDateYear\": [\"2024\"],"
            + "\"PORTLET_DATA_com_liferay_document_library_web_portlet_DLAdminPortlet\": [\"false\"],"
            + "\"DELETIONS\": [\"false\"],"
            + "\"LAYOUT_SET_PROTOTYPE_SETTINGS\": [\"true\"],"
            + "\"startDateAmPm\": [\"1\"],"
            + "\"endDateMonth\": [\"9\"]"
            + "}";
  
  public static Map<String, String[]> jsonToMap() {
      try {
          // Parse JSON string into a JsonNode
          ObjectMapper objectMapper = new ObjectMapper();
          JsonNode rootNode = objectMapper.readTree(jsonString);

          // Create a Map to hold the results
          Map<String, String[]> resultMap = new HashMap<>();

          // Iterate over the fields of the JsonNode
          Iterator<Map.Entry<String, JsonNode>> fields = rootNode.fields();
          while (fields.hasNext()) {
              Map.Entry<String, JsonNode> entry = fields.next();
              String key = entry.getKey();
              JsonNode arrayNode = entry.getValue();

              // Convert the JsonNode array to String[]
              String[] values = new String[arrayNode.size()];
              for (int i = 0; i < arrayNode.size(); i++) {
                  values[i] = arrayNode.get(i).asText();
              }

              // Put the key and values into the result map
              resultMap.put(key, values);
          }

          return resultMap;
      } catch (Exception e) {
          e.printStackTrace();
          return null;
      }
  }
}
