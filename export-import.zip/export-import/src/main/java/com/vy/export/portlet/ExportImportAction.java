package com.vy.export.portlet;

import java.io.File;
import java.io.Serializable;
import java.util.Map;

import javax.portlet.ActionRequest;

import com.liferay.exportimport.kernel.configuration.ExportImportConfigurationSettingsMapFactory;
import com.liferay.exportimport.kernel.configuration.ExportImportConfigurationSettingsMapFactoryUtil;
import com.liferay.exportimport.kernel.configuration.constants.ExportImportConfigurationConstants;
import com.liferay.exportimport.kernel.model.ExportImportConfiguration;
import com.liferay.exportimport.kernel.service.ExportImportConfigurationLocalServiceUtil;
import com.liferay.exportimport.kernel.service.ExportImportLocalServiceUtil;
import com.liferay.portal.kernel.model.LayoutSet;
import com.liferay.portal.kernel.service.LayoutLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;


public class ExportImportAction {

	
	public static File exportSitePages(ThemeDisplay themeDisplay ,ActionRequest actionRequest, long groupId, boolean privateLayout) throws Exception {
		// Get the LayoutSet (private or public pages)
      //  LayoutSet layoutSet = LayoutLocalServiceUtil.getLayoutSet(groupId, privateLayout);
        Map<String, Serializable> exportLayoutSettingsMap = null;
        // Generate a file name for the exported LAR file
        String larFileName = privateLayout ? "private-pages-export.lar" : "public-pages-export.lar";
        File larFile = new File(larFileName);

        // Export pages to LAR file
        

        // Create ExportImportConfiguration for the export
        long[] layoutIds=ExportImportUtil.getLayoutIds(actionRequest);
        Map<String,String[]> hm= ExportImportProperties.jsonToMap();
        exportLayoutSettingsMap =
				ExportImportConfigurationSettingsMapFactoryUtil.
					buildExportLayoutSettingsMap(
						themeDisplay.getUserId(), groupId, privateLayout,
						layoutIds,
						ExportImportProperties.jsonToMap(),
						themeDisplay.getLocale(), themeDisplay.getTimeZone());
        String taskName="Site Pages Copying";
        
        ExportImportConfiguration exportImportConfiguration=ExportImportConfigurationLocalServiceUtil.addDraftExportImportConfiguration(
    			themeDisplay.getUserId(), taskName,
    			ExportImportConfigurationConstants.TYPE_EXPORT_LAYOUT,
    			exportLayoutSettingsMap);
        larFile=ExportImportLocalServiceUtil.exportLayoutsAsFile(exportImportConfiguration);

        
        // Return the generated LAR file
        return larFile;
	}
	
	public static ExportImportConfiguration exportImportConfiguration(ThemeDisplay themeDisplay ,ActionRequest actionRequest, long groupId, boolean privateLayout) throws Exception {
		// Get the LayoutSet (private or public pages)
      //  LayoutSet layoutSet = LayoutLocalServiceUtil.getLayoutSet(groupId, privateLayout);
        Map<String, Serializable> exportLayoutSettingsMap = null;
        // Generate a file name for the exported LAR file
        ExportImportConfiguration exportImportConfiguration=null;

        // Export pages to LAR file
        

        // Create ExportImportConfiguration for the export
        long[] layoutIds=ExportImportUtil.getLayoutIds(actionRequest);
        Map<String,String[]> hm= ExportImportProperties.jsonToMap();
        
        exportLayoutSettingsMap =
				ExportImportConfigurationSettingsMapFactoryUtil.
					buildExportLayoutSettingsMap(
						themeDisplay.getUserId(), groupId, privateLayout,
						layoutIds,
						ExportImportProperties.jsonToMap(),
						themeDisplay.getLocale(), themeDisplay.getTimeZone());
        String taskName="Site Pages Copying";
        
         exportImportConfiguration=ExportImportConfigurationLocalServiceUtil.addDraftExportImportConfiguration(
    			themeDisplay.getUserId(), taskName,
    			ExportImportConfigurationConstants.TYPE_EXPORT_LAYOUT,
    			exportLayoutSettingsMap);

        
        // Return the generated LAR file
        return exportImportConfiguration;
	}
	
	public void importSitePages(ThemeDisplay themeDisplay ,ActionRequest actionRequest,long targetGroupId, boolean privateLayout, File larFile) throws Exception {

        // Import the LAR file into the target site
		ExportImportLocalServiceUtil.importLayouts(exportImportConfiguration(themeDisplay, actionRequest, targetGroupId, privateLayout), larFile);
        
    }
}
