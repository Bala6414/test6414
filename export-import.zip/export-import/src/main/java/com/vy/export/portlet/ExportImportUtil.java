package com.vy.export.portlet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.portlet.PortletRequest;

import com.liferay.portal.kernel.exception.NoSuchLayoutException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.GroupConstants;
import com.liferay.portal.kernel.model.Layout;
import com.liferay.portal.kernel.model.LayoutConstants;
import com.liferay.portal.kernel.service.LayoutLocalService;
import com.liferay.portal.kernel.service.LayoutLocalServiceUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.MapUtil;
import com.liferay.portal.kernel.util.Validator;

public  class ExportImportUtil {
	
	public static long[] getLayoutIds(PortletRequest portletRequest)
			throws PortalException {

			return getLayoutIds(
				getLayoutIdMap(portletRequest),
				GroupConstants.DEFAULT_LIVE_GROUP_ID);
		}
	
	public static Map<Long, Boolean> getLayoutIdMap(PortletRequest portletRequest1)
			throws PortalException {

			String layoutIdsJSON = GetterUtil.getString(
				portletRequest1.getAttribute("layoutIdMap"));
			System.out.println("layoutIdsJSON::"+layoutIdsJSON);

			if (Validator.isNull(layoutIdsJSON)) {
				return Collections.emptyMap();
			}

			Map<Long, Boolean> layoutIdMap = new LinkedHashMap<>();

			JSONArray jsonArray = JSONFactoryUtil.createJSONArray(layoutIdsJSON);

			for (int i = 0; i < jsonArray.length(); ++i) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);

				layoutIdMap.put(
					jsonObject.getLong("plid"),
					jsonObject.getBoolean("includeChildren"));
			}

			return layoutIdMap;
		}
	
	public static long[] getLayoutIds(
			Map<Long, Boolean> layoutIdMap, long targetGroupId)
		throws PortalException {

		if (MapUtil.isEmpty(layoutIdMap)) {
			return new long[0];
		}

		List<Layout> layouts = new ArrayList<>();

		Set<Map.Entry<Long, Boolean>> entrySet = layoutIdMap.entrySet();

		for (Map.Entry<Long, Boolean> entry : entrySet) {
			long plid = GetterUtil.getLong(String.valueOf(entry.getKey()));

			Layout layout = null;

			try {
				layout = getLayoutOrCreateDummyRootLayout(plid);
			}
			catch (NoSuchLayoutException noSuchLayoutException) {
				

				entrySet.remove(plid);

				continue;
			}

			if (!layouts.contains(layout)) {
				layouts.add(layout);
			}

			if (layout.getPlid() == LayoutConstants.DEFAULT_PLID) {
				continue;
			}

			List<Layout> parentLayouts = Collections.emptyList();

			if (targetGroupId != GroupConstants.DEFAULT_LIVE_GROUP_ID) {
				parentLayouts = getMissingParentLayouts(layout, targetGroupId);
			}

			/*if (FeatureFlagManagerUtil.isEnabled("LPS-199086")) {
				try {
					StagingConfiguration stagingConfiguration =
						_configurationProvider.getCompanyConfiguration(
							StagingConfiguration.class,
							CompanyThreadLocal.getCompanyId());

					if (stagingConfiguration.publishParentLayoutsByDefault()) {
						for (Layout parentLayout : parentLayouts) {
							if (!layouts.contains(parentLayout)) {
								layouts.add(parentLayout);
							}
						}
					}
				}
				catch (Exception exception) {
					//_log.error(exception);
				}
			}
			else {
				for (Layout parentLayout : parentLayouts) {
					if (!layouts.contains(parentLayout)) {
						layouts.add(parentLayout);
					}
				}
			}*/

			
			for (Layout parentLayout : parentLayouts) {
				if (!layouts.contains(parentLayout)) {
					layouts.add(parentLayout);
				}
			}
			boolean includeChildren = entry.getValue();

			if (includeChildren) {
				for (Layout childLayout : layout.getAllChildren()) {
					if (!layouts.contains(childLayout)) {
						layouts.add(childLayout);
					}
				}
			}
		}

		return getLayoutIds(layouts);
	}

	public static List<Layout> getMissingParentLayouts(Layout layout, long liveGroupId)
			throws PortalException {

			List<Layout> missingParentLayouts = new ArrayList<>();

			long parentLayoutId = layout.getParentLayoutId();

			Layout parentLayout = null;

			while (parentLayoutId > 0) {
				parentLayout = LayoutLocalServiceUtil.getLayout(
					layout.getGroupId(), layout.isPrivateLayout(), parentLayoutId);

				if (LayoutLocalServiceUtil.hasLayout(
						parentLayout.getUuid(), liveGroupId,
						parentLayout.isPrivateLayout())) {

					// If one parent is found, all others are assumed to exist

					break;
				}

				missingParentLayouts.add(parentLayout);

				parentLayoutId = parentLayout.getParentLayoutId();
			}

			return missingParentLayouts;
		}
	
	public static Layout getLayoutOrCreateDummyRootLayout(long plid)
			throws PortalException {

			Layout layout = LayoutLocalServiceUtil.createLayout(LayoutConstants.DEFAULT_PLID);

			if (plid == 0) {
				//layout.setPlid(LayoutConstants.DEFAULT_PLID);
				layout.setLayoutId(LayoutConstants.DEFAULT_PLID);
				layout.setParentLayoutId(LayoutConstants.DEFAULT_PARENT_LAYOUT_ID);
			}
			else {
				layout = LayoutLocalServiceUtil.getLayout(plid);
			}

			return layout;
		}
	
	public static long[] getLayoutIds(List<Layout> layouts) {
		return layouts.stream().mapToLong(Layout::getLayoutId)
			    .toArray();
		//return TransformUtil.transformToLongArray(layouts, Layout::getLayoutId);
	}
}
