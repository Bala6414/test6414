const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, LevelFormat, HeadingLevel, BorderStyle, WidthType, ShadingType
} = require('docx');

const C_PRIMARY = "1F4E79";
const C_ACCENT  = "2E75B6";
const C_HEADER  = "D5E8F0";
const C_ROW_ALT = "F2F7FB";
const C_BORDER  = "BFBFBF";
const C_CODE_BG = "F4F4F4";
const C_WARN    = "C00000";

const border = { style: BorderStyle.SINGLE, size: 4, color: C_BORDER };
const cellBorders = { top: border, bottom: border, left: border, right: border };

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { after: opts.after ?? 120, before: opts.before ?? 0 },
    alignment: opts.align,
    children: [new TextRun({
      text, bold: opts.bold, italics: opts.italics,
      size: opts.size ?? 22, color: opts.color, font: opts.font
    })]
  });
}

function code(text) {
  return new Paragraph({
    spacing: { after: 60 },
    shading: { fill: C_CODE_BG, type: ShadingType.CLEAR },
    children: [new TextRun({ text, font: "Consolas", size: 18 })]
  });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 280, after: 160 },
    children: [new TextRun({ text, bold: true, size: 32, color: C_PRIMARY })]
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 200, after: 120 },
    children: [new TextRun({ text, bold: true, size: 26, color: C_ACCENT })]
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 160, after: 80 },
    children: [new TextRun({ text, bold: true, size: 22, color: C_PRIMARY })]
  });
}

function numbered(text, ref, level = 0) {
  return new Paragraph({
    numbering: { reference: ref, level },
    spacing: { after: 80 },
    children: [new TextRun({ text, size: 22 })]
  });
}

function bullet(text, level = 0) {
  return new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: { after: 60 },
    children: [new TextRun({ text, size: 22 })]
  });
}

function cell(text, opts = {}) {
  return new TableCell({
    borders: cellBorders,
    width: { size: opts.width, type: WidthType.DXA },
    shading: opts.fill ? { fill: opts.fill, type: ShadingType.CLEAR } : undefined,
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    children: (Array.isArray(text) ? text : [text]).map(t =>
      new Paragraph({
        children: [new TextRun({ text: t, bold: opts.bold, italics: opts.italics, size: opts.size ?? 22, color: opts.color, font: opts.font })]
      })
    )
  });
}

function headerCell(text, width) {
  return cell(text, { width, fill: C_HEADER, bold: true, color: C_PRIMARY });
}

const children = [];

// Title
children.push(new Paragraph({
  alignment: AlignmentType.CENTER, spacing: { after: 80 },
  children: [new TextRun({ text: "BlueWeb — Brand Use Center", bold: true, size: 22, color: C_ACCENT })]
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER, spacing: { after: 80 },
  children: [new TextRun({ text: "Co-Branding Partner Form 17-Question Enhancement", bold: true, size: 36, color: C_PRIMARY })]
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER, spacing: { after: 240 },
  children: [new TextRun({ text: "Implementation & Execution Guide", italics: true, size: 24, color: "595959" })]
}));

// Doc info
children.push(new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2600, 6760],
  rows: [
    new TableRow({ children: [headerCell("Field", 2600), headerCell("Detail", 6760)] }),
    new TableRow({ children: [cell("Module", { width: 2600, bold: true }), cell("BCBSA Brand → Brand Use Center → Co-Branding Partner Form", { width: 6760 })] }),
    new TableRow({ children: [cell("Project", { width: 2600, bold: true }), cell("BlueWeb / BrpPortlet", { width: 6760 })] }),
    new TableRow({ children: [cell("Tech Stack", { width: 2600, bold: true }), cell("Liferay DXP 7.4, Spring MVC, JPA/Hibernate, jQuery", { width: 6760 })] }),
    new TableRow({ children: [cell("Prepared By", { width: 2600, bold: true }), cell("Satish — BlueWeb Development Team", { width: 6760 })] }),
    new TableRow({ children: [cell("Reviewed By", { width: 2600, bold: true }), cell("Lavanya Chimata (Tech Lead), Madalyn Phillips (Business)", { width: 6760 })] }),
  ]
}));
children.push(p(""));

children.push(p(
  "This document accompanies the deliverables zip (BrpPortlet-CoBrand-Enhancement.zip) and provides the step-by-step instructions to apply the changes, build, deploy, and test. Each step references the corresponding file in the zip.",
  { after: 200 }
));

// =============================================================================
// 1. Summary
// =============================================================================
children.push(h1("1. Summary of Changes"));
children.push(p("The Co-Branding Partner Form is being enhanced to:", { after: 120 }));
children.push(bullet("Replace the 5-checkbox \"Cobranding Criteria Requirements\" section with a 17-question dynamic wizard."));
children.push(bullet("Q1–Q9 are new \"Brand Questions\" always shown for every request."));
children.push(bullet("Q10–Q17 are \"Inter-Plan Policy\" questions that appear conditionally based on Service Category selection."));
children.push(bullet("\"Other\" service category is added as an Inter-Plan Policy trigger."));
children.push(bullet("\"Choose Group Account Type\" dropdown is removed from the form."));
children.push(bullet("Pop-up hard stops on disqualifying answers (Q1=No, Q6=No, Q7=Yes, Q9=Yes)."));
children.push(bullet("Legacy records continue to display in My History / Workqueue with their original criteria checkboxes and Group Account Type — no data migration."));
children.push(bullet("Save For Later behavior unchanged — partial data persists exactly as today."));
children.push(p(""));

// =============================================================================
// 2. Files Touched
// =============================================================================
children.push(h1("2. Files Touched"));
children.push(new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [4500, 4860],
  rows: [
    new TableRow({ children: [headerCell("Original Project File", 4500), headerCell("Deliverable in zip", 4860)] }),
    new TableRow({ children: [
      cell("DDL — brand_request table", { width: 4500, bold: true, fill: C_ROW_ALT }),
      cell("ddl/01_alter_brand_request_add_questions.sql", { width: 4860, fill: C_ROW_ALT, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("src/main/java/com/bcbsa/brp/model/BrandRequest.java", { width: 4500, font: "Consolas", size: 20 }),
      cell("java/01_BrandRequest_additions.java", { width: 4860, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("src/main/java/com/bcbsa/brp/vo/BrandRequestVo.java", { width: 4500, fill: C_ROW_ALT, font: "Consolas", size: 20 }),
      cell("java/02_BrandRequestVo_additions.java", { width: 4860, fill: C_ROW_ALT, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("src/main/java/com/bcbsa/brp/model/util/BrandRequestVoMapper.java", { width: 4500, font: "Consolas", size: 20 }),
      cell("java/03_BrandRequestVoMapper_changes.java", { width: 4860, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("src/main/java/com/bcbsa/brp/validation/BrpCobrandingFormValidator.java", { width: 4500, fill: C_ROW_ALT, font: "Consolas", size: 18 }),
      cell("java/04_BrpCobrandingFormValidator_changes.java", { width: 4860, fill: C_ROW_ALT, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("BrandRequestVoMapper.java + BrandRequestServiceImpl.java (CRITICAL)", { width: 4500, font: "Consolas", size: 18, color: C_WARN, bold: true }),
      cell("java/05_CRITICAL_existing_functionality_patches.java", { width: 4860, font: "Consolas", color: C_WARN, bold: true }),
    ]}),
    new TableRow({ children: [
      cell("src/main/resources/messages.properties", { width: 4500, font: "Consolas", size: 20 }),
      cell("resources/messages_additions.properties", { width: 4860, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("src/main/webapp/WEB-INF/jsp/BrpPortlet/newCobrandRequest.jsp", { width: 4500, fill: C_ROW_ALT, font: "Consolas", size: 18 }),
      cell("jsp/01_newCobrandRequest_changes.jsp", { width: 4860, fill: C_ROW_ALT, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("src/main/webapp/WEB-INF/jsp/BrpPortlet/brp-common-preview.jsp", { width: 4500, font: "Consolas", size: 20 }),
      cell("jsp/02_brp_common_preview_changes.jsp", { width: 4860, font: "Consolas" }),
    ]}),
    new TableRow({ children: [
      cell("src/main/webapp/js/main.js", { width: 4500, fill: C_ROW_ALT, font: "Consolas", size: 20 }),
      cell("js/main_js_changes.js", { width: 4860, fill: C_ROW_ALT, font: "Consolas" }),
    ]}),
  ]
}));
children.push(p(""));
children.push(p("Each deliverable file contains clear BEFORE/AFTER markers showing exactly what to remove, where to insert, and what to replace. Original line numbers are referenced where applicable.", { italics: true, after: 200 }));

// =============================================================================
// 3. Pre-flight
// =============================================================================
children.push(h1("3. Pre-Flight Checklist"));
children.push(p("Before starting, confirm the following:", { after: 120 }));
children.push(numbered("Confirm you are working off a fresh feature branch (e.g., feature/cobrand-17-questions) created from master.", "pre"));
children.push(numbered("Verify your DEV MySQL credentials and that you can connect to lportal_brp database.", "pre"));
children.push(numbered("Confirm the BrpPortlet project builds cleanly without modifications: gradle clean build.", "pre"));
children.push(numbered("Take a backup of any local DB data you care about, especially the brand_request table.", "pre"));
children.push(numbered("Pull the deliverables zip and extract to a known location.", "pre"));
children.push(p(""));

// =============================================================================
// 4. Execution Steps
// =============================================================================
children.push(h1("4. Execution Steps — In Order"));
children.push(p("Execute these in the order shown. Each step is independent of the JSP/JS work but the database step must run before any code is deployed.", { after: 200 }));

// Step 1: DDL
children.push(h2("Step 1 — Apply database schema changes (DEV)"));
children.push(p("File: ddl/01_alter_brand_request_add_questions.sql", { italics: true, after: 80 }));
children.push(p("Run the DDL against the DEV database:", { after: 100 }));
children.push(code("mysql -u root -p lportal_brp < 01_alter_brand_request_add_questions.sql"));
children.push(p("Verify the new columns were added:", { after: 60 }));
children.push(code("SELECT COLUMN_NAME, COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS"));
children.push(code("  WHERE TABLE_SCHEMA = 'lportal_brp'"));
children.push(code("    AND TABLE_NAME = 'brand_request'"));
children.push(code("    AND COLUMN_NAME LIKE 'CB_Q%'"));
children.push(code("  ORDER BY COLUMN_NAME;"));
children.push(p("Expected: 22 new columns. The old criteria columns (DEMO_FINANCIAL, etc.) and SRVC_BLUE_BENEFITS / SRVC_NATIONAL_ACCOUNT_MEMBERS / SRVC_SERVICES_ENTAIL must remain untouched.", { after: 120 }));
children.push(p("Reference data update — enable \"Other\" as an IPP trigger:", { bold: true, after: 60 }));
children.push(code("SELECT SRVC_CTGY_NM, SRVC_CTGY_QUE_REQUIRED FROM service_category;"));
children.push(code("-- if 'Other' row has 0, run:"));
children.push(code("UPDATE service_category SET SRVC_CTGY_QUE_REQUIRED = 1 WHERE SRVC_CTGY_NM = 'Other';"));
children.push(p("This is required for the IPP block to fire when a Plan picks \"Other\" as a service category. Skip if already set.", { after: 200 }));

// Step 2: Java entity
children.push(h2("Step 2 — Update BrandRequest entity"));
children.push(p("File: java/01_BrandRequest_additions.java", { italics: true, after: 80 }));
children.push(numbered("Open BrandRequest.java in Eclipse.", "step2"));
children.push(numbered("Locate line 265 (after the existing 5 criteria fields).", "step2"));
children.push(numbered("Insert all the new @Column field declarations from the deliverable file (the block marked \"17-question enhancement start\" → \"end\").", "step2"));
children.push(numbered("Append the corresponding getters/setters at the end of the class (just before the final closing brace).", "step2"));
children.push(numbered("Save and verify there are no compile errors.", "step2"));
children.push(p(""));

// Step 3: Java VO
children.push(h2("Step 3 — Update BrandRequestVo"));
children.push(p("File: java/02_BrandRequestVo_additions.java", { italics: true, after: 80 }));
children.push(numbered("Open BrandRequestVo.java.", "step3"));
children.push(numbered("Add the 23 new private String fields anywhere in the field declaration area (e.g., right after the existing serviceCategoryServiceEntail field around line 89).", "step3"));
children.push(numbered("Append the matching getters/setters with the rest of the accessors.", "step3"));
children.push(numbered("Save and verify compile.", "step3"));
children.push(p(""));

// Step 4: VoMapper
children.push(h2("Step 4 — Update BrandRequestVoMapper"));
children.push(p("File: java/03_BrandRequestVoMapper_changes.java", { italics: true, after: 80 }));
children.push(numbered("Open BrandRequestVoMapper.java.", "step4"));
children.push(numbered("CHANGE 1 — In fromValueObject() around line 311–329: replace the existing service-category-questions block AND criteria block with the new combined block.", "step4"));
children.push(numbered("CHANGE 2 — In toValueObject() around line 567–587: replace the existing display-side blocks with the new version (this version still maps old fields for legacy display).", "step4"));
children.push(numbered("CHANGE 3 — In fromValueObjectSaveForLater() (starts ~line 1066): add the new 17-question block where similar field copying occurs.", "step4"));
children.push(numbered("Save and verify compile.", "step4"));
children.push(p(""));

// Step 5: Validator
children.push(h2("Step 5 — Update BrpCobrandingFormValidator"));
children.push(p("File: java/04_BrpCobrandingFormValidator_changes.java", { italics: true, after: 80 }));
children.push(numbered("Open BrpCobrandingFormValidator.java.", "step5"));
children.push(numbered("CHANGE 1 — Replace the constants block (lines 130–152) with the new field name and message key constants.", "step5"));
children.push(numbered("CHANGE 2 — Inside the validate() method (lines 304–357), replace the existing service-category-questions and criteria-checkbox validation blocks with the new Q1-Q17 cascade-aware block.", "step5"));
children.push(numbered("CHANGE 3 — Add the validateQ14Q15Q16Q17() helper method anywhere among the private methods.", "step5"));
children.push(numbered("CHANGE 4 — Remove the Group Account Type validation block (lines 512–525).", "step5"));
children.push(numbered("Save and verify compile.", "step5"));
children.push(p(""));

// Step 5b: CRITICAL patches
children.push(h2("Step 5b — Apply CRITICAL patches (do not skip)"));
children.push(p("File: java/05_CRITICAL_existing_functionality_patches.java", { italics: true, after: 80 }));
children.push(p("These 3 patches were discovered during cross-reference audit. Without them, existing functionality breaks (NPE on every submit, legacy data wiped on update flows, new fields missing in update flows).", { bold: true, color: C_WARN, after: 100 }));
children.push(numbered("PATCH 1 — In BrandRequestVoMapper.java, replace the legalEntity.setGroupAccountType(...) calls at line 349 AND line 1207 with the null-safe version.", "step5b"));
children.push(numbered("PATCH 2A — In BrandRequestServiceImpl.java line 240, wrap the setGroupAccountType call with a null-check.", "step5b"));
children.push(numbered("PATCH 2B — In BrandRequestServiceImpl.java replace lines 284-294 with the guarded version that ALSO sets all the new Q1-Q17 fields.", "step5b"));
children.push(numbered("Save both files and verify compile.", "step5b"));
children.push(p(""));

// Step 6: messages.properties
children.push(h2("Step 6 — Add message keys"));
children.push(p("File: resources/messages_additions.properties", { italics: true, after: 80 }));
children.push(numbered("Open src/main/resources/messages.properties.", "step6"));
children.push(numbered("Append the entire content of the deliverable file at the END of messages.properties.", "step6"));
children.push(numbered("Old keys (lines 52-61) can be left in place — they are harmless and may still be referenced by legacy display logic.", "step6"));
children.push(numbered("Save the file.", "step6"));
children.push(p(""));

// Step 7: JSP form
children.push(h2("Step 7 — Update form JSP"));
children.push(p("File: jsp/01_newCobrandRequest_changes.jsp", { italics: true, after: 80 }));
children.push(numbered("Open src/main/webapp/WEB-INF/jsp/BrpPortlet/newCobrandRequest.jsp.", "step7"));
children.push(numbered("CHANGE 1 — DELETE lines 315–366 (the entire existing service-category-questions block AND criteria checkboxes block). Replace with the new Q1-Q9 + Q10-Q17 markup from the deliverable.", "step7"));
children.push(numbered("CHANGE 2 — DELETE the Group Account Type block (lines 562–575).", "step7"));
children.push(numbered("CHANGE 3 — Add the 4 pop-up dialog containers near the existing dialogs around line 745.", "step7"));
children.push(numbered("Save the file.", "step7"));
children.push(p(""));

// Step 8: Preview JSP
children.push(h2("Step 8 — Update preview JSP"));
children.push(p("File: jsp/02_brp_common_preview_changes.jsp", { italics: true, after: 80 }));
children.push(numbered("Open src/main/webapp/WEB-INF/jsp/BrpPortlet/brp-common-preview.jsp.", "step8"));
children.push(numbered("CHANGE 1 — Replace lines 66–88 with the new Q1-Q17 display block.", "step8"));
children.push(numbered("CHANGE 2 — Wrap the legacy criteria block (lines 90–132) with the legacy-only c:if as shown.", "step8"));
children.push(numbered("CHANGE 3 — Wrap the Group Account Type display (lines 199–204) with a not-empty c:if check.", "step8"));
children.push(numbered("Save the file.", "step8"));
children.push(p(""));

// Step 9: JS
children.push(h2("Step 9 — Update main.js"));
children.push(p("File: js/main_js_changes.js", { italics: true, after: 80 }));
children.push(numbered("Open src/main/webapp/js/main.js.", "step9"));
children.push(numbered("CHANGE 1 — DELETE the old criteria checkbox click handlers (lines 36–118, the block bracketed by \"Cobranding Criteria Requirement customisation start/end\").", "step9"));
children.push(numbered("CHANGE 2 — Replace the showDiv() function (lines 1611–1640) with the updated version.", "step9"));
children.push(numbered("CHANGE 3 — Append the entire 17-question enhancement block at the end of main.js (the $(document).ready() block plus the helper functions).", "step9"));
children.push(numbered("Save the file.", "step9"));
children.push(p(""));

// =============================================================================
// 5. Build & Deploy
// =============================================================================
children.push(h1("5. Build & Deploy"));
children.push(numbered("From the BrpPortlet project root:", "build"));
children.push(code("gradle clean build"));
children.push(numbered("Confirm the build is GREEN. If errors appear, re-check imports, missing semicolons, or unresolved references.", "build"));
children.push(numbered("Locate the WAR file in build/libs/ (or wherever your build output is configured).", "build"));
children.push(numbered("Deploy the WAR to the DEV Liferay instance:", "build"));
children.push(code("cp BrpPortlet.war $LIFERAY_HOME/deploy/"));
children.push(numbered("Tail the Tomcat / Liferay logs to confirm clean deployment.", "build"));
children.push(p(""));

// =============================================================================
// 6. Testing
// =============================================================================
children.push(h1("6. Testing Plan"));

children.push(h2("6.1 Smoke test — basic form load"));
children.push(numbered("Navigate to Brand Use Center → Co-Branding → New Co-Branding Request.", "smoke"));
children.push(numbered("Confirm the form renders without JS errors (check browser console).", "smoke"));
children.push(numbered("Confirm the new \"Brand Questions\" section appears after Service Categories with Q1–Q9 visible.", "smoke"));
children.push(numbered("Confirm the old criteria checkbox section is GONE.", "smoke"));
children.push(numbered("Confirm \"Choose Group Account Type\" dropdown is GONE.", "smoke"));
children.push(p(""));

children.push(h2("6.2 Q1–Q9 sub-field cascade tests"));
children.push(bullet("Q2 = Yes → date field appears; user can type or use date picker."));
children.push(bullet("Q2 = No → date field hides and clears."));
children.push(bullet("Q3 = Yes → acknowledgement checkbox appears."));
children.push(bullet("Q4 = Yes → 3 sub-fields (links textarea, contact textarea, ack checkbox) appear."));
children.push(bullet("Q5 = Yes → 3 sub-fields appear (parallel to Q4)."));
children.push(bullet("Q8 = No → informational note appears below the question."));
children.push(p(""));

children.push(h2("6.3 Pop-up hard stops"));
children.push(bullet("Q1 = No → pop-up appears, radio is unselected, cannot proceed until changed to Yes."));
children.push(bullet("Q6 = No → pop-up appears, radio is unselected."));
children.push(bullet("Q7 = Yes → pop-up appears, radio is unselected."));
children.push(bullet("Q9 = Yes → pop-up appears, radio is unselected."));
children.push(p(""));

children.push(h2("6.4 IPP cascade — Q10 to Q17"));
children.push(bullet("Select a triggering Service Category (e.g., Care and Disease Management). The IPP block (Q10–Q11) must appear."));
children.push(bullet("Select \"Other\" service category. The IPP block must appear."));
children.push(bullet("Q11 = Carveout → no further IPP questions."));
children.push(bullet("Q11 = Generates a claim → Q12 appears."));
children.push(bullet("Q11 = Other → text box + Q14, Q15, Q16 appear; Q12, Q13 do not appear."));
children.push(bullet("Q11 = Generates a claim → Q12 = Yes → Q13 appears."));
children.push(bullet("Q12 = Yes → Q13 = Yes (virtual only) → STOP, no Q14-Q17."));
children.push(bullet("Q12 = Yes → Q13 = No → Q14, Q15, Q16 appear."));
children.push(bullet("Q12 = No → Q14, Q15, Q16 appear; Q13 does not."));
children.push(bullet("Q16 = Yes → Q17 appears."));
children.push(bullet("Q16 = No → Q17 hides."));
children.push(p(""));

children.push(h2("6.5 Service categories deselect"));
children.push(bullet("Deselect ALL triggering service categories. The IPP block must hide entirely and clear all Q10–Q17 values."));
children.push(p(""));

children.push(h2("6.6 Save For Later"));
children.push(bullet("Fill out partial data including some Q1–Q9 answers and some Q10–Q17 answers. Click \"Save For Later\"."));
children.push(bullet("Reopen the saved request from My History."));
children.push(bullet("Confirm: all entered values are restored AND the cascade UI state matches (sub-fields visible where parent answer was Yes)."));
children.push(p(""));

children.push(h2("6.7 Submit happy path"));
children.push(bullet("Fill out all required fields with valid (non-blocking) answers. Submit."));
children.push(bullet("Verify the request is saved by querying the brand_request table — confirm new CB_Q* columns are populated."));
children.push(bullet("Open the request from My History — preview should display all Q1–Q17 answers."));
children.push(p(""));

children.push(h2("6.8 Validation errors"));
children.push(bullet("Try to submit with required fields empty. Confirm error messages appear inline next to each field."));
children.push(bullet("Verify Q11 = Other without describing → error on Q11 \"Other\" text field."));
children.push(bullet("Verify Q4 = Yes without filling links/contact/ack → 3 separate errors."));
children.push(p(""));

children.push(h2("6.9 Legacy record viewing"));
children.push(bullet("Use a request submitted BEFORE this enhancement (or test with a record where new CB_Q* columns are NULL but old criteria columns have values)."));
children.push(bullet("Open it via My History."));
children.push(bullet("Preview must show: old criteria checkbox values + Group Account Type, AND must NOT show empty Q1–Q17 sections."));
children.push(p(""));

// =============================================================================
// 7. Rollback
// =============================================================================
children.push(h1("7. Rollback Plan"));
children.push(numbered("Redeploy the previous WAR to revert the code.", "roll"));
children.push(numbered("If schema must be rolled back, run the DROP COLUMN statements at the bottom of the DDL file (commented out by default).", "roll"));
children.push(numbered("Existing data in the new CB_Q* columns will be lost on schema rollback. Old records remain unaffected.", "roll"));
children.push(p(""));

// =============================================================================
// 8. Promotion path
// =============================================================================
children.push(h1("8. Promotion Path"));
children.push(p("After DEV testing passes, follow the standard BlueWeb deployment path:", { after: 80 }));
children.push(numbered("DEV → QA — apply DDL to QA DB, deploy WAR to QA Liferay. Madalyn / business validates UX.", "promo"));
children.push(numbered("QA → PROD — apply DDL to PROD DB during scheduled maintenance window, deploy WAR. Smoke test in PROD.", "promo"));
children.push(numbered("Same QA/PROD Graph API + Tomcat upgrade flow applies — coordinate with Imran for env-specific config if needed.", "promo"));
children.push(p(""));

// =============================================================================
// 9. Open items
// =============================================================================
children.push(h1("9. Known Open Items / Future Work"));
children.push(bullet("Excel reports (CoBrand-BCBSA-Report.xlsx, CoBrand-Plans-Report.xlsx) — confirmed not in scope per Madalyn. Revisit if business asks for the new Q1-Q17 fields to appear in reports."));
children.push(bullet("Workqueue display — currently uses the same brp-common-preview.jsp, so legacy + new records render correctly through that. If a separate Workqueue JSP exists with its own criteria display, apply the same pattern."));
children.push(bullet("Group Account Type reference data loading in AbstractCobrandRequestController.decorateModelWithReferenceData() — leaving it intact (harmless even though no longer used by form). Can be cleaned up in a future maintenance pass."));
children.push(p(""));

children.push(p(""));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  border: { top: { style: BorderStyle.SINGLE, size: 8, color: C_ACCENT, space: 4 } },
  spacing: { before: 240 },
  children: [new TextRun({ text: "End of document", italics: true, size: 20, color: "808080" })]
}));

// numbering
const refs = ["pre","step2","step3","step4","step5","step5b","step6","step7","step8","step9","build","smoke","roll","promo"];
const numberingConfig = refs.map(ref => ({
  reference: ref,
  levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
}));
numberingConfig.push({
  reference: "bullets",
  levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
});

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Calibri", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Calibri", color: C_PRIMARY },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: "Calibri", color: C_ACCENT },
        paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: "Calibri", color: C_PRIMARY },
        paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
    ]
  },
  numbering: { config: numberingConfig },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    children
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/claude/delivery/docs/CoBrand_Enhancement_Execution_Guide.docx", buffer);
  console.log("Done.");
});
