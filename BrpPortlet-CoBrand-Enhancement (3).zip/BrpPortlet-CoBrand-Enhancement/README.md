# BlueWeb — Co-Branding Partner Form 17-Question Enhancement
## Deliverables Package

This zip contains all changes required to implement the 17-question enhancement
to the Co-Branding Partner Form in the BrpPortlet module.

## Start here
**docs/CoBrand_Enhancement_Execution_Guide.docx**

That document is the master playbook. It walks through every step in order
(DDL → Java → properties → JSPs → JS → patches → build → deploy → test → rollback).
Open it first, follow it top to bottom.

## Folder layout

```
ddl/
  01_alter_brand_request_add_questions.sql      DDL to add 22 new columns +
                                                "Other" service category flag UPDATE

java/
  01_BrandRequest_additions.java                Entity additions
  02_BrandRequestVo_additions.java              VO additions (mirror)
  03_BrandRequestVoMapper_changes.java          Mapping changes (3 sections)
  04_BrpCobrandingFormValidator_changes.java    Validator changes (4 sections)
  05_CRITICAL_existing_functionality_patches.java  >>> REQUIRED <<< 3 patches
                                                to prevent existing-functionality
                                                breakage (NPE on submit, legacy
                                                data wipe, missing update flow)

resources/
  messages_additions.properties                 i18n keys (append)

jsp/
  01_newCobrandRequest_changes.jsp              Form JSP (3 sections)
  02_brp_common_preview_changes.jsp             Preview JSP (3 sections)

js/
  main_js_changes.js                            JS (4 sections)

docs/
  CoBrand_Enhancement_Execution_Guide.docx      Master execution document
  generate.js                                   Source script
```

## ⚠️ DO NOT SKIP file 05

`java/05_CRITICAL_existing_functionality_patches.java` contains 3 fixes
discovered during a cross-reference audit:

1. NullPointerException — VoMapper lines 349 and 1207 chain
   `vo.getGroupAccountType().getGrpAcctTypCd()` which crashes once the form
   no longer collects Group Account Type.

2. Legacy data wipe in updateBrandRequest — unguarded setters would null
   out preserved legacy values (criteria checkboxes, Group Account Type)
   when an existing legacy record is updated post-deployment.

3. Missing new-field setters in updateBrandRequest — without these, the
   17 new question values would not persist when an existing request is
   updated (e.g., approver finalizing a save-for-later).

## Notes on the change-instruction files

The Java/JSP/JS files are NOT drop-in replacements. They contain the specific
snippets to insert/replace, with clear BEFORE/AFTER markers and original
line-number references. Open the deliverable next to the original in Eclipse
and follow the markers section by section.

## Database notes

- 22 new columns added to `brand_request` table.
- One UPDATE on `service_category` to enable "Other" as IPP trigger.
- Old criteria columns (DEMO_FINANCIAL, NO_FELONY_RECORD, etc.) and
  `GRP_ACCT_TYP_CD` are NOT dropped — legacy records remain viewable.
- Existing columns SRVC_BLUE_BENEFITS, SRVC_NATIONAL_ACCOUNT_MEMBERS,
  SRVC_SERVICES_ENTAIL are REUSED for Q11, Q14, Q15 respectively.

## Behavior change — Excel reports (acknowledged)

`ReportsAbstractController` and `BcbcaCoBrandRepo` keep working but for new
records:
- Old criteria columns will be NULL
- SRVC_BLUE_BENEFITS will hold "CARVEOUT"/"CLAIM"/"OTHER" instead of free text
- SRVC_NATIONAL_ACCOUNT_MEMBERS will hold "Y"/"N" instead of free text

Madalyn confirmed report updates are out of scope for this enhancement.

## Contact

Author: Satish (BlueWeb Development Team)
Tech Lead: Lavanya Chimata
Business: Madalyn Phillips
