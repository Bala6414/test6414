// =============================================================================
// File: src/main/java/com/bcbsa/brp/validation/BrpCobrandingFormValidator.java
// Action: 4 changes in this file.
// =============================================================================

// -----------------------------------------------------------------------------
// CHANGE 1: Constants block (around lines 130-152)
// REPLACE the existing constants for old criteria + service category questions.
// -----------------------------------------------------------------------------
//
// FIND AND REMOVE these lines (130-152):
//      private static String FIELD_SRVC_BLUE_BENEFITS = "serviceCategoryBlueBenefit";
//      private static String FIELD_SRVC_NATIONAL_ACCOUNT_MEMBERS = "serviceCategoryNationalAccountMember";
//      private static String FIELD_SRVC_SERVICES_ENTAIL = "serviceCategoryServiceEntail";
//      private static String MESSAGE_KEY_SRVC_BLUE_BENEFITS_REQUIRED = "field.serviceCategoryBlueBenefit.required";
//      private static String MESSAGE_KEY_SRVC_NATIONAL_ACCOUNT_MEMBERS_REQUIRED = "field.serviceCategoryNationalAccountMember.required";
//      private static String MESSAGE_KEY_SRVC_SERVICES_ENTAIL_REQUIRED = "field.serviceCategoryServiceEntail.required";
//      ... blank line ...
//      private static String FIELD_DEMO_FINANCIAL = "demoFinancial";
//      private static String FIELD_NO_FELONY_RECORDS = "noFelonyRecord";
//      private static String FIELD_REPUTATION_BRANDS = "reputationBrand";
//      private static String FIELD_PROHIBITED_COMPANY ="prohibitatedCompany";
//      private static String FIELD_NO_MISUSE_OF_BRANDS="noMisuseOfBrands";
//      private static String MESSAGE_KEY_DEMO_FINANCIAL_REQUIRED = "field.demoFinancial.required";
//      private static String MESSAGE_KEY_NO_FELONY_RECORDS_REQUIRED = "field.noFelonyRecord.required";
//      private static String MESSAGE_KEY_REPUTATION_BRANDS_REQUIRED = "field.reputationBrand.required";
//      private static String MESSAGE_KEY_PROHIBITED_COMPANY_REQUIRED = "field.prohibitatedCompany.required";
//      private static String MESSAGE_KEY_NO_MISUSE_OF_BRANDS_REQUIRED = "field.noMisuseOfBrands.required";
//
// REPLACE WITH:

	//Co-Branding Partner Form 17-question enhancement constants start

	// Q1-Q9 Brand Questions (always required for new submissions)
	private static String FIELD_Q1_LEGAL_NAME = "cbQ1LegalNameCnfrmd";
	private static String FIELD_Q2_DEBIT_CARD = "cbQ2DebitCardInd";
	private static String FIELD_Q2_LICENSE_DT = "cbQ2LicenseAgmtDt";
	private static String FIELD_Q3_CLIENT_LIST = "cbQ3ClientListInd";
	private static String FIELD_Q3_EXCEPTION_ACK = "cbQ3ExceptionAckInd";
	private static String FIELD_Q4_BRAND_MISUSE = "cbQ4BrandMisuseInd";
	private static String FIELD_Q4_LINKS = "cbQ4MisuseLinksTxt";
	private static String FIELD_Q4_CONTACT = "cbQ4MisuseContactTxt";
	private static String FIELD_Q4_ACK = "cbQ4MisuseAckInd";
	private static String FIELD_Q5_INFRNG = "cbQ5NameLogoInfrngInd";
	private static String FIELD_Q5_LINKS = "cbQ5InfrngLinksTxt";
	private static String FIELD_Q5_CONTACT = "cbQ5InfrngContactTxt";
	private static String FIELD_Q5_ACK = "cbQ5InfrngAckInd";
	private static String FIELD_Q6_FINL_STABLE = "cbQ6FinlStableInd";
	private static String FIELD_Q7_FELONY = "cbQ7FelonyInd";
	private static String FIELD_Q8_NOT_ON_LIST = "cbQ8NotOnListInd";
	private static String FIELD_Q9_REPUTATION = "cbQ9ReputationInd";

	// Q10-Q17 IPP Questions (required only when serviceCatQuestionsFlag = Y)
	private static String FIELD_Q10_IPP_EXEC = "cbQ10InterPlanExecTxt";
	private static String FIELD_Q11_BLUE_BENEFITS = "serviceCategoryBlueBenefit";
	private static String FIELD_Q11_OTHER_TXT = "cbQ11OtherTxt";
	private static String FIELD_Q12_TELEHEALTH = "cbQ12TelehealthSvcInd";
	private static String FIELD_Q13_VIRTUAL_ONLY = "cbQ13VirtualOnlyInd";
	private static String FIELD_Q14_NATL_MEMBERS = "serviceCategoryNationalAccountMember";
	private static String FIELD_Q15_SERVICES_ENTAIL = "serviceCategoryServiceEntail";
	private static String FIELD_Q16_PROVIDER_OUTREACH = "cbQ16ProviderOutreachInd";
	private static String FIELD_Q17_PROVIDER_OUTREACH_TXT = "cbQ17ProviderOutreachTxt";

	// Message keys
	private static String MSG_Q1_REQUIRED = "field.cbQ1.required";
	private static String MSG_Q2_REQUIRED = "field.cbQ2.required";
	private static String MSG_Q2_DATE_REQUIRED = "field.cbQ2Date.required";
	private static String MSG_Q3_REQUIRED = "field.cbQ3.required";
	private static String MSG_Q3_ACK_REQUIRED = "field.cbQ3Ack.required";
	private static String MSG_Q4_REQUIRED = "field.cbQ4.required";
	private static String MSG_Q4_LINKS_REQUIRED = "field.cbQ4Links.required";
	private static String MSG_Q4_CONTACT_REQUIRED = "field.cbQ4Contact.required";
	private static String MSG_Q4_ACK_REQUIRED = "field.cbQ4Ack.required";
	private static String MSG_Q5_REQUIRED = "field.cbQ5.required";
	private static String MSG_Q5_LINKS_REQUIRED = "field.cbQ5Links.required";
	private static String MSG_Q5_CONTACT_REQUIRED = "field.cbQ5Contact.required";
	private static String MSG_Q5_ACK_REQUIRED = "field.cbQ5Ack.required";
	private static String MSG_Q6_REQUIRED = "field.cbQ6.required";
	private static String MSG_Q7_REQUIRED = "field.cbQ7.required";
	private static String MSG_Q8_REQUIRED = "field.cbQ8.required";
	private static String MSG_Q9_REQUIRED = "field.cbQ9.required";
	private static String MSG_Q10_REQUIRED = "field.cbQ10.required";
	private static String MSG_Q11_REQUIRED = "field.cbQ11.required";
	private static String MSG_Q11_OTHER_REQUIRED = "field.cbQ11Other.required";
	private static String MSG_Q12_REQUIRED = "field.cbQ12.required";
	private static String MSG_Q13_REQUIRED = "field.cbQ13.required";
	private static String MSG_Q14_REQUIRED = "field.cbQ14.required";
	private static String MSG_Q15_REQUIRED = "field.cbQ15.required";
	private static String MSG_Q16_REQUIRED = "field.cbQ16.required";
	private static String MSG_Q17_REQUIRED = "field.cbQ17.required";

	// Constants for Q11 radio values
	private static final String Q11_CARVEOUT = "CARVEOUT";
	private static final String Q11_CLAIM = "CLAIM";
	private static final String Q11_OTHER = "OTHER";

	//Co-Branding Partner Form 17-question enhancement constants end


// -----------------------------------------------------------------------------
// CHANGE 2: Inside validate() method - around lines 304-357
// REPLACE the existing service-category questions block AND criteria
// requirements block with the new Q1-Q17 cascade-aware validation.
// -----------------------------------------------------------------------------
//
// FIND THE EXISTING CODE BLOCK (lines 304-357):
//
//      // Validating Service Category questions enhancement start
//      String ServiceCatQuestionsFlag=brandRequestVo.getServiceCatQuestionsFlag();
//      if(ServiceCatQuestionsFlag.equalsIgnoreCase("Y")) {
//          ...3 ValidationUtils.rejectIfEmptyOrWhitespace calls for old fields...
//      }
//      // Validating Service Category questions enhancement end
//
//      // ValidatingC obranding Criteria Requirements  checkboxes start
//      //commenting for future release start
//      String demoFinancial=brandRequestVo.getDemoFinancial();
//      ...5 if-blocks for the 5 old checkboxes...
//      //commenting for future release end
//      // Validating Cobranding Criteria Requirements checkboxes end
//
// REPLACE WITH:

		//Co-Branding Partner Form 17-question enhancement validation start

		// --- Q1-Q9 Brand Questions: always required ---
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q1_LEGAL_NAME, MSG_Q1_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q2_DEBIT_CARD, MSG_Q2_REQUIRED);

		// Q2: if Yes, date is required
		String q2 = brandRequestVo.getCbQ2DebitCardInd();
		if ("Y".equalsIgnoreCase(q2)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q2_LICENSE_DT, MSG_Q2_DATE_REQUIRED);
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q3_CLIENT_LIST, MSG_Q3_REQUIRED);
		// Q3: if Yes, acknowledgement checkbox required
		String q3 = brandRequestVo.getCbQ3ClientListInd();
		if ("Y".equalsIgnoreCase(q3)) {
			if (!"Y".equalsIgnoreCase(brandRequestVo.getCbQ3ExceptionAckInd())) {
				errors.rejectValue(FIELD_Q3_EXCEPTION_ACK, MSG_Q3_ACK_REQUIRED);
			}
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q4_BRAND_MISUSE, MSG_Q4_REQUIRED);
		// Q4: if Yes, links + contact + ack all required
		String q4 = brandRequestVo.getCbQ4BrandMisuseInd();
		if ("Y".equalsIgnoreCase(q4)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q4_LINKS, MSG_Q4_LINKS_REQUIRED);
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q4_CONTACT, MSG_Q4_CONTACT_REQUIRED);
			if (!"Y".equalsIgnoreCase(brandRequestVo.getCbQ4MisuseAckInd())) {
				errors.rejectValue(FIELD_Q4_ACK, MSG_Q4_ACK_REQUIRED);
			}
			santizeInput(brandRequestVo.getCbQ4MisuseLinksTxt());
			santizeInput(brandRequestVo.getCbQ4MisuseContactTxt());
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q5_INFRNG, MSG_Q5_REQUIRED);
		// Q5: if Yes, links + contact + ack all required
		String q5 = brandRequestVo.getCbQ5NameLogoInfrngInd();
		if ("Y".equalsIgnoreCase(q5)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q5_LINKS, MSG_Q5_LINKS_REQUIRED);
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q5_CONTACT, MSG_Q5_CONTACT_REQUIRED);
			if (!"Y".equalsIgnoreCase(brandRequestVo.getCbQ5InfrngAckInd())) {
				errors.rejectValue(FIELD_Q5_ACK, MSG_Q5_ACK_REQUIRED);
			}
			santizeInput(brandRequestVo.getCbQ5InfrngLinksTxt());
			santizeInput(brandRequestVo.getCbQ5InfrngContactTxt());
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q6_FINL_STABLE, MSG_Q6_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q7_FELONY, MSG_Q7_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q8_NOT_ON_LIST, MSG_Q8_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q9_REPUTATION, MSG_Q9_REQUIRED);

		// --- Q10-Q17 IPP Questions: required only when serviceCatQuestionsFlag = Y ---
		String serviceCatQuestionsFlag = brandRequestVo.getServiceCatQuestionsFlag();
		if (serviceCatQuestionsFlag != null && serviceCatQuestionsFlag.equalsIgnoreCase("Y")) {

			// Q10 Inter-Plan Executive
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q10_IPP_EXEC, MSG_Q10_REQUIRED);
			santizeInput(brandRequestVo.getCbQ10InterPlanExecTxt());

			// Q11 radio (CARVEOUT / CLAIM / OTHER)
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q11_BLUE_BENEFITS, MSG_Q11_REQUIRED);
			String q11 = brandRequestVo.getServiceCategoryBlueBenefit();
			if (StringUtils.isNotEmpty(q11)) {
				q11 = santizeInput(q11);
			}

			// Q11 = OTHER -> require Q11 other-text -> jump to Q14, Q15, Q16
			if (Q11_OTHER.equalsIgnoreCase(q11)) {
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q11_OTHER_TXT, MSG_Q11_OTHER_REQUIRED);
				santizeInput(brandRequestVo.getCbQ11OtherTxt());
				validateQ14Q15Q16Q17(brandRequestVo, errors);
			}
			// Q11 = CLAIM -> Q12 required, then cascade
			else if (Q11_CLAIM.equalsIgnoreCase(q11)) {
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q12_TELEHEALTH, MSG_Q12_REQUIRED);
				String q12 = brandRequestVo.getCbQ12TelehealthSvcInd();
				if ("Y".equalsIgnoreCase(q12)) {
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q13_VIRTUAL_ONLY, MSG_Q13_REQUIRED);
					String q13 = brandRequestVo.getCbQ13VirtualOnlyInd();
					if ("N".equalsIgnoreCase(q13)) {
						// Q13 = No (in-person too) -> Q14, Q15, Q16
						validateQ14Q15Q16Q17(brandRequestVo, errors);
					}
					// Q13 = Yes (virtual only) -> STOP, no further questions
				} else if ("N".equalsIgnoreCase(q12)) {
					// Q12 = No -> Q14, Q15, Q16
					validateQ14Q15Q16Q17(brandRequestVo, errors);
				}
			}
			// Q11 = CARVEOUT -> STOP, no further questions
		}
		//Co-Branding Partner Form 17-question enhancement validation end


// -----------------------------------------------------------------------------
// CHANGE 3: ADD this private helper method to the validator class
// (place it near the other private/helper methods at the bottom of the class).
// -----------------------------------------------------------------------------

	/**
	 * Validates Q14, Q15, Q16, Q17 in the IPP cascade.
	 * Called from multiple branches of the Q11/Q12/Q13 cascade.
	 */
	private void validateQ14Q15Q16Q17(BrandRequestVo brandRequestVo, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q14_NATL_MEMBERS, MSG_Q14_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q15_SERVICES_ENTAIL, MSG_Q15_REQUIRED);
		santizeInput(brandRequestVo.getServiceCategoryServiceEntail());

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q16_PROVIDER_OUTREACH, MSG_Q16_REQUIRED);
		String q16 = brandRequestVo.getCbQ16ProviderOutreachInd();
		if ("Y".equalsIgnoreCase(q16)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q17_PROVIDER_OUTREACH_TXT, MSG_Q17_REQUIRED);
			santizeInput(brandRequestVo.getCbQ17ProviderOutreachTxt());
		}
	}


// -----------------------------------------------------------------------------
// CHANGE 4: Group Account Type validation block - around lines 512-525
// REMOVE THE ENTIRE BLOCK:
//
//      // Validating Group Account Type
//      GroupAccountTypeVo groupAccountType = brandRequestVo.getGroupAccountType();
//      if (groupAccountType == null) {
//          errors.rejectValue(FIELD_GROUP_ACCOUNT_TYPE, MESSAGE_KEY_GROUP_ACCOUNT_TYPE_REQUIRED);
//      } else {
//          String groupAccountTypeCode = groupAccountType.getGrpAcctTypCd();
//          if (StringUtils.isNotEmpty(groupAccountTypeCode)) {
//              groupAccountTypeCode = santizeInput(groupAccountTypeCode);
//          }
//          if (StringUtils.isNotEmpty(groupAccountTypeCode) && groupAccountTypeCode.equals("0")) {
//              errors.rejectValue(FIELD_GROUP_ACCOUNT_TYPE, MESSAGE_KEY_GROUP_ACCOUNT_TYPE_REQUIRED);
//          }
//      }
//
// FIELD_GROUP_ACCOUNT_TYPE constant at line 45 can stay (harmless) or be removed.
// MESSAGE_KEY_GROUP_ACCOUNT_TYPE_REQUIRED can also stay or be removed.

// =============================================================================
// NOTE about pop-up blockers:
// Pop-up hard stops (Q1=No, Q6=No, Q7=Yes, Q9=Yes) are handled in JavaScript
// (newCobrand.js) which prevents form submission. This server-side validator
// only enforces required-field presence as a safety net.
// =============================================================================
