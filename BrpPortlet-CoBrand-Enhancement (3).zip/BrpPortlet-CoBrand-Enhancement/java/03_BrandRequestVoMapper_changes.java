// =============================================================================
// File: src/main/java/com/bcbsa/brp/model/util/BrandRequestVoMapper.java
// Action: 3 sections to modify in this file.
// =============================================================================

// -----------------------------------------------------------------------------
// CHANGE 1: fromValueObject() method - around line 311-329
// REPLACE the existing service-category questions block AND the criteria
// requirements block with this new combined block.
// -----------------------------------------------------------------------------
//
// FIND THIS EXISTING CODE (line ~311 to line ~329):
//
//      //Service Category question hide and show customisation start
//      String serviceCatQueFlag=vo.getServiceCatQuestionsFlag();
//      if(serviceCatQueFlag.equalsIgnoreCase("Y")) {
//      ret.setServiceCategoryBlueBenefit(vo.getServiceCategoryBlueBenefit());
//      ret.setServiceCategoryNationalAccountMember(vo.getServiceCategoryNationalAccountMember());
//      ret.setServiceCategoryServiceEntail(vo.getServiceCategoryServiceEntail());
//      ret.setServiceCatQuestionsFlag("Y");
//      }
//      //Service Category question hide and show customisation end
//
//      //Cobranding Criteria Requirement customisation start
//      //commenting for future release start
//      ret.setDemoFinancial(vo.getDemoFinancial());
//      ret.setNoFelonyRecord(vo.getNoFelonyRecord());
//      ret.setReputationBrand(vo.getReputationBrand());
//      ret.setProhibitatedCompany(vo.getProhibitatedCompany());
//      ret.setNoMisuseOfBrands(vo.getNoMisuseOfBrands());
//      //commenting for future release end
//      //Cobranding Criteria Requirement customisation end
//
// REPLACE WITH THIS:

		//Co-Branding Partner Form 17-question enhancement start
		//Q1-Q9 Brand Questions - always saved (always shown on form)
		ret.setCbQ1LegalNameCnfrmd(vo.getCbQ1LegalNameCnfrmd());
		ret.setCbQ2DebitCardInd(vo.getCbQ2DebitCardInd());
		ret.setCbQ2LicenseAgmtDt(vo.getCbQ2LicenseAgmtDt());
		ret.setCbQ3ClientListInd(vo.getCbQ3ClientListInd());
		ret.setCbQ3ExceptionAckInd(vo.getCbQ3ExceptionAckInd());
		ret.setCbQ4BrandMisuseInd(vo.getCbQ4BrandMisuseInd());
		ret.setCbQ4MisuseLinksTxt(vo.getCbQ4MisuseLinksTxt());
		ret.setCbQ4MisuseContactTxt(vo.getCbQ4MisuseContactTxt());
		ret.setCbQ4MisuseAckInd(vo.getCbQ4MisuseAckInd());
		ret.setCbQ5NameLogoInfrngInd(vo.getCbQ5NameLogoInfrngInd());
		ret.setCbQ5InfrngLinksTxt(vo.getCbQ5InfrngLinksTxt());
		ret.setCbQ5InfrngContactTxt(vo.getCbQ5InfrngContactTxt());
		ret.setCbQ5InfrngAckInd(vo.getCbQ5InfrngAckInd());
		ret.setCbQ6FinlStableInd(vo.getCbQ6FinlStableInd());
		ret.setCbQ7FelonyInd(vo.getCbQ7FelonyInd());
		ret.setCbQ8NotOnListInd(vo.getCbQ8NotOnListInd());
		ret.setCbQ9ReputationInd(vo.getCbQ9ReputationInd());

		//Q10-Q17 IPP Questions - saved only when service-category triggered
		String serviceCatQueFlag = vo.getServiceCatQuestionsFlag();
		if (serviceCatQueFlag != null && serviceCatQueFlag.equalsIgnoreCase("Y")) {
			ret.setCbQ10InterPlanExecTxt(vo.getCbQ10InterPlanExecTxt());

			// Q11 radio value (CARVEOUT / CLAIM / OTHER) reuses SRVC_BLUE_BENEFITS column
			ret.setServiceCategoryBlueBenefit(vo.getServiceCategoryBlueBenefit());
			ret.setCbQ11OtherTxt(vo.getCbQ11OtherTxt());

			ret.setCbQ12TelehealthSvcInd(vo.getCbQ12TelehealthSvcInd());
			ret.setCbQ13VirtualOnlyInd(vo.getCbQ13VirtualOnlyInd());

			// Q14 reuses SRVC_NATIONAL_ACCOUNT_MEMBERS column (now Y/N)
			ret.setServiceCategoryNationalAccountMember(vo.getServiceCategoryNationalAccountMember());

			// Q15 reuses SRVC_SERVICES_ENTAIL column (free text)
			ret.setServiceCategoryServiceEntail(vo.getServiceCategoryServiceEntail());

			ret.setCbQ16ProviderOutreachInd(vo.getCbQ16ProviderOutreachInd());
			ret.setCbQ17ProviderOutreachTxt(vo.getCbQ17ProviderOutreachTxt());

			ret.setServiceCatQuestionsFlag("Y");
		}
		//Note: old criteria fields (demoFinancial, noFelonyRecord, reputationBrand,
		//      prohibitatedCompany, noMisuseOfBrands) are intentionally NOT set here.
		//      They remain in the entity/DB for legacy display only.
		//Co-Branding Partner Form 17-question enhancement end


// -----------------------------------------------------------------------------
// CHANGE 2: toValueObject() method - around line 567-587
// REPLACE the existing service-category questions block AND criteria
// requirements block with this updated block.
// This is the DISPLAY direction (entity -> VO). Old fields are still mapped
// here so that legacy records continue to display correctly.
// -----------------------------------------------------------------------------
//
// FIND THIS EXISTING CODE (line ~567 to line ~587):
//
//      //Service Category Questions Customisation start
//      if(source.getServiceCategoryBlueBenefit() !=null && source.getServiceCategoryNationalAccountMember() !=null && source.getServiceCategoryServiceEntail() !=null) {
//          log.info("Setting Service Category Questions Flag to Yes");
//          ret.setServiceCatQuestionsFlag("Y");
//          ret.setServiceCategoryBlueBenefit(source.getServiceCategoryBlueBenefit());
//          ret.setServiceCategoryNationalAccountMember(source.getServiceCategoryNationalAccountMember());
//          ret.setServiceCategoryServiceEntail(source.getServiceCategoryServiceEntail());
//      }
//      //Service Category Questions Customisation end
//      //Cobranding Criteria Requirement customisation start
//      //commenting for future release start
//      if(source.getDemoFinancial()!="N" && source.getNoFelonyRecord()!="N" && source.getProhibitatedCompany()!="N"&& source.getReputationBrand()!="N" && source.getNoMisuseOfBrands()!="N") {
//          log.info("Setting Cobranding criteria requirement");
//          ret.setDemoFinancial(source.getDemoFinancial());
//          ret.setNoFelonyRecord(source.getNoFelonyRecord());
//          ret.setProhibitatedCompany(source.getProhibitatedCompany());
//          ret.setReputationBrand(source.getReputationBrand());
//          ret.setNoMisuseOfBrands(source.getNoMisuseOfBrands());
//      }
//      //commenting for future release start
//      //Cobranding Criteria Requirement customisation end
//
// REPLACE WITH THIS:

		//Co-Branding Partner Form 17-question enhancement start
		//Q1-Q9 Brand Questions - always loaded for display
		ret.setCbQ1LegalNameCnfrmd(source.getCbQ1LegalNameCnfrmd());
		ret.setCbQ2DebitCardInd(source.getCbQ2DebitCardInd());
		ret.setCbQ2LicenseAgmtDt(source.getCbQ2LicenseAgmtDt());
		ret.setCbQ3ClientListInd(source.getCbQ3ClientListInd());
		ret.setCbQ3ExceptionAckInd(source.getCbQ3ExceptionAckInd());
		ret.setCbQ4BrandMisuseInd(source.getCbQ4BrandMisuseInd());
		ret.setCbQ4MisuseLinksTxt(source.getCbQ4MisuseLinksTxt());
		ret.setCbQ4MisuseContactTxt(source.getCbQ4MisuseContactTxt());
		ret.setCbQ4MisuseAckInd(source.getCbQ4MisuseAckInd());
		ret.setCbQ5NameLogoInfrngInd(source.getCbQ5NameLogoInfrngInd());
		ret.setCbQ5InfrngLinksTxt(source.getCbQ5InfrngLinksTxt());
		ret.setCbQ5InfrngContactTxt(source.getCbQ5InfrngContactTxt());
		ret.setCbQ5InfrngAckInd(source.getCbQ5InfrngAckInd());
		ret.setCbQ6FinlStableInd(source.getCbQ6FinlStableInd());
		ret.setCbQ7FelonyInd(source.getCbQ7FelonyInd());
		ret.setCbQ8NotOnListInd(source.getCbQ8NotOnListInd());
		ret.setCbQ9ReputationInd(source.getCbQ9ReputationInd());

		//Q10-Q17 IPP Questions
		ret.setCbQ10InterPlanExecTxt(source.getCbQ10InterPlanExecTxt());
		ret.setCbQ11OtherTxt(source.getCbQ11OtherTxt());
		ret.setCbQ12TelehealthSvcInd(source.getCbQ12TelehealthSvcInd());
		ret.setCbQ13VirtualOnlyInd(source.getCbQ13VirtualOnlyInd());
		ret.setCbQ16ProviderOutreachInd(source.getCbQ16ProviderOutreachInd());
		ret.setCbQ17ProviderOutreachTxt(source.getCbQ17ProviderOutreachTxt());

		// Existing service-category-question fields - kept for both new (Q11/Q14/Q15)
		// and legacy display
		if (source.getServiceCategoryBlueBenefit() != null
				|| source.getServiceCategoryNationalAccountMember() != null
				|| source.getServiceCategoryServiceEntail() != null) {
			ret.setServiceCatQuestionsFlag("Y");
			ret.setServiceCategoryBlueBenefit(source.getServiceCategoryBlueBenefit());
			ret.setServiceCategoryNationalAccountMember(source.getServiceCategoryNationalAccountMember());
			ret.setServiceCategoryServiceEntail(source.getServiceCategoryServiceEntail());
		}

		// Legacy criteria fields - still loaded for old records so My History /
		// Workqueue can display them. New records will have these as null.
		ret.setDemoFinancial(source.getDemoFinancial());
		ret.setNoFelonyRecord(source.getNoFelonyRecord());
		ret.setProhibitatedCompany(source.getProhibitatedCompany());
		ret.setReputationBrand(source.getReputationBrand());
		ret.setNoMisuseOfBrands(source.getNoMisuseOfBrands());
		//Co-Branding Partner Form 17-question enhancement end


// -----------------------------------------------------------------------------
// CHANGE 3: fromValueObjectSaveForLater() method - starts at line ~1066
// ADD this block to also persist the 17 new question values when saving
// for later. Find where the method does its main field copying (similar to
// fromValueObject) and add the same Q1-Q17 block.
//
// IMPORTANT: Save-for-later must NOT enforce required-field rules but should
// still persist any partial values entered, so use the same setter calls as
// fromValueObject without the conditional gate on serviceCatQuestionsFlag.
// -----------------------------------------------------------------------------
//
// Find a logical place inside fromValueObjectSaveForLater() (after the
// service-category-related setter section) and ADD:

		//Co-Branding Partner Form 17-question enhancement (save for later) start
		ret.setCbQ1LegalNameCnfrmd(vo.getCbQ1LegalNameCnfrmd());
		ret.setCbQ2DebitCardInd(vo.getCbQ2DebitCardInd());
		ret.setCbQ2LicenseAgmtDt(vo.getCbQ2LicenseAgmtDt());
		ret.setCbQ3ClientListInd(vo.getCbQ3ClientListInd());
		ret.setCbQ3ExceptionAckInd(vo.getCbQ3ExceptionAckInd());
		ret.setCbQ4BrandMisuseInd(vo.getCbQ4BrandMisuseInd());
		ret.setCbQ4MisuseLinksTxt(vo.getCbQ4MisuseLinksTxt());
		ret.setCbQ4MisuseContactTxt(vo.getCbQ4MisuseContactTxt());
		ret.setCbQ4MisuseAckInd(vo.getCbQ4MisuseAckInd());
		ret.setCbQ5NameLogoInfrngInd(vo.getCbQ5NameLogoInfrngInd());
		ret.setCbQ5InfrngLinksTxt(vo.getCbQ5InfrngLinksTxt());
		ret.setCbQ5InfrngContactTxt(vo.getCbQ5InfrngContactTxt());
		ret.setCbQ5InfrngAckInd(vo.getCbQ5InfrngAckInd());
		ret.setCbQ6FinlStableInd(vo.getCbQ6FinlStableInd());
		ret.setCbQ7FelonyInd(vo.getCbQ7FelonyInd());
		ret.setCbQ8NotOnListInd(vo.getCbQ8NotOnListInd());
		ret.setCbQ9ReputationInd(vo.getCbQ9ReputationInd());
		ret.setCbQ10InterPlanExecTxt(vo.getCbQ10InterPlanExecTxt());
		ret.setServiceCategoryBlueBenefit(vo.getServiceCategoryBlueBenefit());
		ret.setCbQ11OtherTxt(vo.getCbQ11OtherTxt());
		ret.setCbQ12TelehealthSvcInd(vo.getCbQ12TelehealthSvcInd());
		ret.setCbQ13VirtualOnlyInd(vo.getCbQ13VirtualOnlyInd());
		ret.setServiceCategoryNationalAccountMember(vo.getServiceCategoryNationalAccountMember());
		ret.setServiceCategoryServiceEntail(vo.getServiceCategoryServiceEntail());
		ret.setCbQ16ProviderOutreachInd(vo.getCbQ16ProviderOutreachInd());
		ret.setCbQ17ProviderOutreachTxt(vo.getCbQ17ProviderOutreachTxt());
		if (vo.getServiceCatQuestionsFlag() != null
				&& vo.getServiceCatQuestionsFlag().equalsIgnoreCase("Y")) {
			ret.setServiceCatQuestionsFlag("Y");
		}
		//Co-Branding Partner Form 17-question enhancement (save for later) end
