// =============================================================================
// CRITICAL PATCHES — discovered during cross-reference audit
// =============================================================================
// These changes are REQUIRED to prevent existing functionality from breaking.
// Apply these IN ADDITION to the changes in 03_BrandRequestVoMapper_changes.java.
// =============================================================================


// =============================================================================
// PATCH 1: NullPointerException on form submit
// File: src/main/java/com/bcbsa/brp/model/util/BrandRequestVoMapper.java
// Lines: 349 and 1207
// =============================================================================
//
// Since the form no longer collects Group Account Type, vo.getGroupAccountType()
// returns null. The chained .getGrpAcctTypCd() call therefore throws NPE on
// every new submission AND every save-for-later.
//
// FIND (BOTH lines 349 AND 1207, identical code):
//
//      legalEntity.setGroupAccountType(getSelectedGroupAccountType(vo.getGroupAccountType().getGrpAcctTypCd()));
//
// REPLACE WITH (BOTH locations):

		// Co-Branding Partner Form 17-question enhancement: form no longer
		// collects Group Account Type. Skip if not provided to avoid NPE and
		// to preserve any existing value on the LegalEntity (legacy data).
		if (vo.getGroupAccountType() != null
				&& vo.getGroupAccountType().getGrpAcctTypCd() != null
				&& !vo.getGroupAccountType().getGrpAcctTypCd().isEmpty()
				&& !"0".equals(vo.getGroupAccountType().getGrpAcctTypCd())) {
			legalEntity.setGroupAccountType(getSelectedGroupAccountType(vo.getGroupAccountType().getGrpAcctTypCd()));
		}


// =============================================================================
// PATCH 2: Legacy data wipe in updateBrandRequest
// File: src/main/java/com/bcbsa/brp/service/impl/BrandRequestServiceImpl.java
// Lines: 240 (legalEntity.setGroupAccountType) and 290-294 (criteria fields)
// =============================================================================
//
// updateBrandRequest is called when an existing request is updated, e.g.:
//   - Status change by a BCBSA approver
//   - Save-for-later request being finalized
//   - Renewal flow
//
// After our enhancement, incoming brandRequest will have NULL values for the
// removed fields (Group Account Type, demoFinancial, noFelonyRecord, etc.)
// and the 3 reused service-category-question columns will hold new-style
// values (CARVEOUT/CLAIM/OTHER for blueBenefit, Y/N for nationalAccount, etc.).
//
// For a LEGACY request being updated, these blind setters would overwrite
// preserved legacy data with nulls / new-style values. We must guard them.
//
// ----- FIX 2A: Line 240 -----
//
// FIND:
//
//      existingBrandRequest.getLegalEntity().setGroupAccountType(newLegalEntity.getGroupAccountType());
//
// REPLACE WITH:

		// Only update Group Account Type if the incoming value is non-null
		// (form no longer collects it; preserve existing legacy value).
		if (newLegalEntity.getGroupAccountType() != null) {
			existingBrandRequest.getLegalEntity().setGroupAccountType(newLegalEntity.getGroupAccountType());
		}


// ----- FIX 2B: Lines 284-294 (the service-category-question + criteria block) -----
//
// FIND THE EXISTING BLOCK:
//
//      //service category questions enhancement start
//      existingBrandRequest.setServiceCategoryBlueBenefit(brandRequest.getServiceCategoryBlueBenefit());
//      existingBrandRequest.setServiceCategoryNationalAccountMember(brandRequest.getServiceCategoryNationalAccountMember());
//      existingBrandRequest.setServiceCategoryServiceEntail(brandRequest.getServiceCategoryServiceEntail());
//      existingBrandRequest.setServiceCatQuestionsFlag(brandRequest.getServiceCatQuestionsFlag());
//      //service category questions enhancement end
//      //commenting for future release start
//      existingBrandRequest.setDemoFinancial(brandRequest.getDemoFinancial());
//      existingBrandRequest.setNoFelonyRecord(brandRequest.getNoFelonyRecord());
//      existingBrandRequest.setReputationBrand(brandRequest.getReputationBrand());
//      existingBrandRequest.setProhibitatedCompany(brandRequest.getProhibitatedCompany());
//      existingBrandRequest.setNoMisuseOfBrands(brandRequest.getNoMisuseOfBrands());
//      //commenting for future release end
//
// REPLACE WITH:

			//Co-Branding Partner Form 17-question enhancement (update flow) start

			// Service-category questions: 3 reused columns (Q11/Q14/Q15)
			// + flag - update if provided.
			if (brandRequest.getServiceCategoryBlueBenefit() != null) {
				existingBrandRequest.setServiceCategoryBlueBenefit(brandRequest.getServiceCategoryBlueBenefit());
			}
			if (brandRequest.getServiceCategoryNationalAccountMember() != null) {
				existingBrandRequest.setServiceCategoryNationalAccountMember(brandRequest.getServiceCategoryNationalAccountMember());
			}
			if (brandRequest.getServiceCategoryServiceEntail() != null) {
				existingBrandRequest.setServiceCategoryServiceEntail(brandRequest.getServiceCategoryServiceEntail());
			}
			if (brandRequest.getServiceCatQuestionsFlag() != null) {
				existingBrandRequest.setServiceCatQuestionsFlag(brandRequest.getServiceCatQuestionsFlag());
			}

			// Legacy criteria fields: only update if incoming is non-null.
			// New submissions leave these null - preserve any legacy value.
			if (brandRequest.getDemoFinancial() != null) {
				existingBrandRequest.setDemoFinancial(brandRequest.getDemoFinancial());
			}
			if (brandRequest.getNoFelonyRecord() != null) {
				existingBrandRequest.setNoFelonyRecord(brandRequest.getNoFelonyRecord());
			}
			if (brandRequest.getReputationBrand() != null) {
				existingBrandRequest.setReputationBrand(brandRequest.getReputationBrand());
			}
			if (brandRequest.getProhibitatedCompany() != null) {
				existingBrandRequest.setProhibitatedCompany(brandRequest.getProhibitatedCompany());
			}
			if (brandRequest.getNoMisuseOfBrands() != null) {
				existingBrandRequest.setNoMisuseOfBrands(brandRequest.getNoMisuseOfBrands());
			}

			// New Q1-Q9 Brand Questions and Q10/Q11other/Q12/Q13/Q16/Q17 IPP fields
			if (brandRequest.getCbQ1LegalNameCnfrmd() != null) existingBrandRequest.setCbQ1LegalNameCnfrmd(brandRequest.getCbQ1LegalNameCnfrmd());
			if (brandRequest.getCbQ2DebitCardInd() != null) existingBrandRequest.setCbQ2DebitCardInd(brandRequest.getCbQ2DebitCardInd());
			if (brandRequest.getCbQ2LicenseAgmtDt() != null) existingBrandRequest.setCbQ2LicenseAgmtDt(brandRequest.getCbQ2LicenseAgmtDt());
			if (brandRequest.getCbQ3ClientListInd() != null) existingBrandRequest.setCbQ3ClientListInd(brandRequest.getCbQ3ClientListInd());
			if (brandRequest.getCbQ3ExceptionAckInd() != null) existingBrandRequest.setCbQ3ExceptionAckInd(brandRequest.getCbQ3ExceptionAckInd());
			if (brandRequest.getCbQ4BrandMisuseInd() != null) existingBrandRequest.setCbQ4BrandMisuseInd(brandRequest.getCbQ4BrandMisuseInd());
			if (brandRequest.getCbQ4MisuseLinksTxt() != null) existingBrandRequest.setCbQ4MisuseLinksTxt(brandRequest.getCbQ4MisuseLinksTxt());
			if (brandRequest.getCbQ4MisuseContactTxt() != null) existingBrandRequest.setCbQ4MisuseContactTxt(brandRequest.getCbQ4MisuseContactTxt());
			if (brandRequest.getCbQ4MisuseAckInd() != null) existingBrandRequest.setCbQ4MisuseAckInd(brandRequest.getCbQ4MisuseAckInd());
			if (brandRequest.getCbQ5NameLogoInfrngInd() != null) existingBrandRequest.setCbQ5NameLogoInfrngInd(brandRequest.getCbQ5NameLogoInfrngInd());
			if (brandRequest.getCbQ5InfrngLinksTxt() != null) existingBrandRequest.setCbQ5InfrngLinksTxt(brandRequest.getCbQ5InfrngLinksTxt());
			if (brandRequest.getCbQ5InfrngContactTxt() != null) existingBrandRequest.setCbQ5InfrngContactTxt(brandRequest.getCbQ5InfrngContactTxt());
			if (brandRequest.getCbQ5InfrngAckInd() != null) existingBrandRequest.setCbQ5InfrngAckInd(brandRequest.getCbQ5InfrngAckInd());
			if (brandRequest.getCbQ6FinlStableInd() != null) existingBrandRequest.setCbQ6FinlStableInd(brandRequest.getCbQ6FinlStableInd());
			if (brandRequest.getCbQ7FelonyInd() != null) existingBrandRequest.setCbQ7FelonyInd(brandRequest.getCbQ7FelonyInd());
			if (brandRequest.getCbQ8NotOnListInd() != null) existingBrandRequest.setCbQ8NotOnListInd(brandRequest.getCbQ8NotOnListInd());
			if (brandRequest.getCbQ9ReputationInd() != null) existingBrandRequest.setCbQ9ReputationInd(brandRequest.getCbQ9ReputationInd());
			if (brandRequest.getCbQ10InterPlanExecTxt() != null) existingBrandRequest.setCbQ10InterPlanExecTxt(brandRequest.getCbQ10InterPlanExecTxt());
			if (brandRequest.getCbQ11OtherTxt() != null) existingBrandRequest.setCbQ11OtherTxt(brandRequest.getCbQ11OtherTxt());
			if (brandRequest.getCbQ12TelehealthSvcInd() != null) existingBrandRequest.setCbQ12TelehealthSvcInd(brandRequest.getCbQ12TelehealthSvcInd());
			if (brandRequest.getCbQ13VirtualOnlyInd() != null) existingBrandRequest.setCbQ13VirtualOnlyInd(brandRequest.getCbQ13VirtualOnlyInd());
			if (brandRequest.getCbQ16ProviderOutreachInd() != null) existingBrandRequest.setCbQ16ProviderOutreachInd(brandRequest.getCbQ16ProviderOutreachInd());
			if (brandRequest.getCbQ17ProviderOutreachTxt() != null) existingBrandRequest.setCbQ17ProviderOutreachTxt(brandRequest.getCbQ17ProviderOutreachTxt());

			//Co-Branding Partner Form 17-question enhancement (update flow) end


// =============================================================================
// PATCH 3 (verification only): ReportsAbstractController + BcbcaCoBrandRepo
// =============================================================================
//
// These are USED BY the Excel report generation that Madalyn confirmed is
// out of scope for this enhancement.
//
// File: src/main/java/com/bcbsa/brp/controller/ReportsAbstractController.java
// File: src/main/java/com/bcbsa/brp/model/BcbcaCoBrandRepo.java
//
// These reference DEMO_FINANCIAL, NO_FELONY_RECORD, REPUTATION_BRANDS,
// PROHIBITED_CPMNY, NO_MISUSE_OF_BRANDS, SRVC_BLUE_BENEFITS,
// SRVC_NATIONAL_ACCOUNT_MEMBERS, SRVC_SERVICES_ENTAIL.
//
// NO ACTION NEEDED - the columns still exist in the database.
// Reports will keep running. Behavior change to expect:
//   - Old criteria columns: NULL for new records, populated for legacy records
//   - SRVC_BLUE_BENEFITS: "CARVEOUT" / "CLAIM" / "OTHER" for new IPP records,
//       free text for legacy records
//   - SRVC_NATIONAL_ACCOUNT_MEMBERS: "Y" / "N" for new records, free text for legacy
//   - SRVC_SERVICES_ENTAIL: free text in both cases (no semantic change)
//
// If a future business request asks to update reports to include Q1-Q17,
// it would be a separate ticket.
