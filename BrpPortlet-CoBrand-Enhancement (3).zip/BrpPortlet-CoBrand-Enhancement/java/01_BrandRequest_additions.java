// =============================================================================
// File: src/main/java/com/bcbsa/brp/model/BrandRequest.java
// Action: ADD these fields and their getters/setters.
//         Insert AFTER line 265 (after the "Cobranding Criteria Requirement
//         customisation end" comment block).
//         DO NOT remove any existing fields - legacy records still need them.
// =============================================================================

	//Co-Branding Partner Form 17-question enhancement start

	// Q1
	@Column(name = "CB_Q1_LEGAL_NAME_CNFRMD")
	private String cbQ1LegalNameCnfrmd;

	// Q2
	@Column(name = "CB_Q2_DEBIT_CARD_IND")
	private String cbQ2DebitCardInd;

	@Column(name = "CB_Q2_LICENSE_AGMT_DT")
	private String cbQ2LicenseAgmtDt;

	// Q3
	@Column(name = "CB_Q3_CLIENT_LIST_IND")
	private String cbQ3ClientListInd;

	@Column(name = "CB_Q3_EXCEPTION_ACK_IND")
	private String cbQ3ExceptionAckInd;

	// Q4
	@Column(name = "CB_Q4_BRAND_MISUSE_IND")
	private String cbQ4BrandMisuseInd;

	@Column(name = "CB_Q4_MISUSE_LINKS_TXT")
	private String cbQ4MisuseLinksTxt;

	@Column(name = "CB_Q4_MISUSE_CONTACT_TXT")
	private String cbQ4MisuseContactTxt;

	@Column(name = "CB_Q4_MISUSE_ACK_IND")
	private String cbQ4MisuseAckInd;

	// Q5
	@Column(name = "CB_Q5_NAME_LOGO_INFRNG_IND")
	private String cbQ5NameLogoInfrngInd;

	@Column(name = "CB_Q5_INFRNG_LINKS_TXT")
	private String cbQ5InfrngLinksTxt;

	@Column(name = "CB_Q5_INFRNG_CONTACT_TXT")
	private String cbQ5InfrngContactTxt;

	@Column(name = "CB_Q5_INFRNG_ACK_IND")
	private String cbQ5InfrngAckInd;

	// Q6
	@Column(name = "CB_Q6_FINL_STABLE_IND")
	private String cbQ6FinlStableInd;

	// Q7
	@Column(name = "CB_Q7_FELONY_IND")
	private String cbQ7FelonyInd;

	// Q8
	@Column(name = "CB_Q8_NOT_ON_LIST_IND")
	private String cbQ8NotOnListInd;

	// Q9
	@Column(name = "CB_Q9_REPUTATION_IND")
	private String cbQ9ReputationInd;

	// Q10 (IPP)
	@Column(name = "CB_Q10_INTER_PLAN_EXEC_TXT")
	private String cbQ10InterPlanExecTxt;

	// Q11 (IPP) - radio value (CARVEOUT / CLAIM / OTHER) is stored in
	//             existing column SRVC_BLUE_BENEFITS (field: serviceCategoryBlueBenefit)
	// Q11 - "Other" free text:
	@Column(name = "CB_Q11_OTHER_TXT")
	private String cbQ11OtherTxt;

	// Q12 (IPP)
	@Column(name = "CB_Q12_TELEHEALTH_SVC_IND")
	private String cbQ12TelehealthSvcInd;

	// Q13 (IPP)
	@Column(name = "CB_Q13_VIRTUAL_ONLY_IND")
	private String cbQ13VirtualOnlyInd;

	// Q14 (IPP) - reuses existing column SRVC_NATIONAL_ACCOUNT_MEMBERS
	//             (field: serviceCategoryNationalAccountMember). Stores Y/N for new records.

	// Q15 (IPP) - reuses existing column SRVC_SERVICES_ENTAIL
	//             (field: serviceCategoryServiceEntail). No semantic change.

	// Q16 (IPP)
	@Column(name = "CB_Q16_PROVIDER_OUTREACH_IND")
	private String cbQ16ProviderOutreachInd;

	// Q17 (IPP)
	@Column(name = "CB_Q17_PROVIDER_OUTREACH_TXT")
	private String cbQ17ProviderOutreachTxt;

	//Co-Branding Partner Form 17-question enhancement end


// =============================================================================
// Getters and setters - append AFTER existing setters but BEFORE the closing
// brace of the BrandRequest class.
// =============================================================================

	//Co-Branding Partner Form 17-question getters/setters start

	public String getCbQ1LegalNameCnfrmd() { return cbQ1LegalNameCnfrmd; }
	public void setCbQ1LegalNameCnfrmd(String v) { this.cbQ1LegalNameCnfrmd = v; }

	public String getCbQ2DebitCardInd() { return cbQ2DebitCardInd; }
	public void setCbQ2DebitCardInd(String v) { this.cbQ2DebitCardInd = v; }

	public String getCbQ2LicenseAgmtDt() { return cbQ2LicenseAgmtDt; }
	public void setCbQ2LicenseAgmtDt(String v) { this.cbQ2LicenseAgmtDt = v; }

	public String getCbQ3ClientListInd() { return cbQ3ClientListInd; }
	public void setCbQ3ClientListInd(String v) { this.cbQ3ClientListInd = v; }

	public String getCbQ3ExceptionAckInd() { return cbQ3ExceptionAckInd; }
	public void setCbQ3ExceptionAckInd(String v) { this.cbQ3ExceptionAckInd = v; }

	public String getCbQ4BrandMisuseInd() { return cbQ4BrandMisuseInd; }
	public void setCbQ4BrandMisuseInd(String v) { this.cbQ4BrandMisuseInd = v; }

	public String getCbQ4MisuseLinksTxt() { return cbQ4MisuseLinksTxt; }
	public void setCbQ4MisuseLinksTxt(String v) { this.cbQ4MisuseLinksTxt = v; }

	public String getCbQ4MisuseContactTxt() { return cbQ4MisuseContactTxt; }
	public void setCbQ4MisuseContactTxt(String v) { this.cbQ4MisuseContactTxt = v; }

	public String getCbQ4MisuseAckInd() { return cbQ4MisuseAckInd; }
	public void setCbQ4MisuseAckInd(String v) { this.cbQ4MisuseAckInd = v; }

	public String getCbQ5NameLogoInfrngInd() { return cbQ5NameLogoInfrngInd; }
	public void setCbQ5NameLogoInfrngInd(String v) { this.cbQ5NameLogoInfrngInd = v; }

	public String getCbQ5InfrngLinksTxt() { return cbQ5InfrngLinksTxt; }
	public void setCbQ5InfrngLinksTxt(String v) { this.cbQ5InfrngLinksTxt = v; }

	public String getCbQ5InfrngContactTxt() { return cbQ5InfrngContactTxt; }
	public void setCbQ5InfrngContactTxt(String v) { this.cbQ5InfrngContactTxt = v; }

	public String getCbQ5InfrngAckInd() { return cbQ5InfrngAckInd; }
	public void setCbQ5InfrngAckInd(String v) { this.cbQ5InfrngAckInd = v; }

	public String getCbQ6FinlStableInd() { return cbQ6FinlStableInd; }
	public void setCbQ6FinlStableInd(String v) { this.cbQ6FinlStableInd = v; }

	public String getCbQ7FelonyInd() { return cbQ7FelonyInd; }
	public void setCbQ7FelonyInd(String v) { this.cbQ7FelonyInd = v; }

	public String getCbQ8NotOnListInd() { return cbQ8NotOnListInd; }
	public void setCbQ8NotOnListInd(String v) { this.cbQ8NotOnListInd = v; }

	public String getCbQ9ReputationInd() { return cbQ9ReputationInd; }
	public void setCbQ9ReputationInd(String v) { this.cbQ9ReputationInd = v; }

	public String getCbQ10InterPlanExecTxt() { return cbQ10InterPlanExecTxt; }
	public void setCbQ10InterPlanExecTxt(String v) { this.cbQ10InterPlanExecTxt = v; }

	public String getCbQ11OtherTxt() { return cbQ11OtherTxt; }
	public void setCbQ11OtherTxt(String v) { this.cbQ11OtherTxt = v; }

	public String getCbQ12TelehealthSvcInd() { return cbQ12TelehealthSvcInd; }
	public void setCbQ12TelehealthSvcInd(String v) { this.cbQ12TelehealthSvcInd = v; }

	public String getCbQ13VirtualOnlyInd() { return cbQ13VirtualOnlyInd; }
	public void setCbQ13VirtualOnlyInd(String v) { this.cbQ13VirtualOnlyInd = v; }

	public String getCbQ16ProviderOutreachInd() { return cbQ16ProviderOutreachInd; }
	public void setCbQ16ProviderOutreachInd(String v) { this.cbQ16ProviderOutreachInd = v; }

	public String getCbQ17ProviderOutreachTxt() { return cbQ17ProviderOutreachTxt; }
	public void setCbQ17ProviderOutreachTxt(String v) { this.cbQ17ProviderOutreachTxt = v; }

	//Co-Branding Partner Form 17-question getters/setters end
