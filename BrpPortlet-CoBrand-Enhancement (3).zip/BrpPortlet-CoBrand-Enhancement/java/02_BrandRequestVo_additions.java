// =============================================================================
// File: src/main/java/com/bcbsa/brp/vo/BrandRequestVo.java
// Action: ADD these fields and getters/setters to BrandRequestVo.
//         Insert AFTER existing serviceCategoryServiceEntail field area (line 89)
//         OR after the noMisuseOfBrands setter (around line 131).
//         Choose a clean location consistent with existing organization.
//         DO NOT remove existing fields - they are needed for legacy display.
// =============================================================================

	//Co-Branding Partner Form 17-question enhancement start

	private String cbQ1LegalNameCnfrmd;
	private String cbQ2DebitCardInd;
	private String cbQ2LicenseAgmtDt;
	private String cbQ3ClientListInd;
	private String cbQ3ExceptionAckInd;
	private String cbQ4BrandMisuseInd;
	private String cbQ4MisuseLinksTxt;
	private String cbQ4MisuseContactTxt;
	private String cbQ4MisuseAckInd;
	private String cbQ5NameLogoInfrngInd;
	private String cbQ5InfrngLinksTxt;
	private String cbQ5InfrngContactTxt;
	private String cbQ5InfrngAckInd;
	private String cbQ6FinlStableInd;
	private String cbQ7FelonyInd;
	private String cbQ8NotOnListInd;
	private String cbQ9ReputationInd;
	private String cbQ10InterPlanExecTxt;
	private String cbQ11OtherTxt;
	private String cbQ12TelehealthSvcInd;
	private String cbQ13VirtualOnlyInd;
	private String cbQ16ProviderOutreachInd;
	private String cbQ17ProviderOutreachTxt;

	//Co-Branding Partner Form 17-question enhancement end


// =============================================================================
// Getters and setters - append these along with the rest of the getters/setters
// =============================================================================

	public String getCbQ1LegalNameCnfrmd() { return cbQ1LegalNameCnfrmd; }
	public void setCbQ1LegalNameCnfrmd(String v) { this.cbQ1LegalNameCnfrmd = v; }

	public String getCbQ2DebitCardInd() { return cbQ2DebitCardInd; }
	public void setCbQ2DebitCardInd(String v) { this.cbQ2DebitCardInd = v; }

	public String getCbQ2LicenseAgmtDt() { return cbQ2LicenseAgmtDt; }
	public void setCbQ2LicenseAgmtDt(String v) { this.cbQ2LicenseAgmtDt = v; }

	public String getCbQ3ClientListInd() { return cbQ3ClientListInd; }
	public void setCbQ3ClientListInd(String v) { this.cbQ3ClientListInd = v; }

	public String getCbQ3ExceptionAckInd() { return cbQ3ExceptionAckInd; }
	public void setCbQ3ExceptionAckInd(String v) { this.cbQ3ExceptionAckInd = v; }

	public String getCbQ4BrandMisuseInd() { return cbQ4BrandMisuseInd; }
	public void setCbQ4BrandMisuseInd(String v) { this.cbQ4BrandMisuseInd = v; }

	public String getCbQ4MisuseLinksTxt() { return cbQ4MisuseLinksTxt; }
	public void setCbQ4MisuseLinksTxt(String v) { this.cbQ4MisuseLinksTxt = v; }

	public String getCbQ4MisuseContactTxt() { return cbQ4MisuseContactTxt; }
	public void setCbQ4MisuseContactTxt(String v) { this.cbQ4MisuseContactTxt = v; }

	public String getCbQ4MisuseAckInd() { return cbQ4MisuseAckInd; }
	public void setCbQ4MisuseAckInd(String v) { this.cbQ4MisuseAckInd = v; }

	public String getCbQ5NameLogoInfrngInd() { return cbQ5NameLogoInfrngInd; }
	public void setCbQ5NameLogoInfrngInd(String v) { this.cbQ5NameLogoInfrngInd = v; }

	public String getCbQ5InfrngLinksTxt() { return cbQ5InfrngLinksTxt; }
	public void setCbQ5InfrngLinksTxt(String v) { this.cbQ5InfrngLinksTxt = v; }

	public String getCbQ5InfrngContactTxt() { return cbQ5InfrngContactTxt; }
	public void setCbQ5InfrngContactTxt(String v) { this.cbQ5InfrngContactTxt = v; }

	public String getCbQ5InfrngAckInd() { return cbQ5InfrngAckInd; }
	public void setCbQ5InfrngAckInd(String v) { this.cbQ5InfrngAckInd = v; }

	public String getCbQ6FinlStableInd() { return cbQ6FinlStableInd; }
	public void setCbQ6FinlStableInd(String v) { this.cbQ6FinlStableInd = v; }

	public String getCbQ7FelonyInd() { return cbQ7FelonyInd; }
	public void setCbQ7FelonyInd(String v) { this.cbQ7FelonyInd = v; }

	public String getCbQ8NotOnListInd() { return cbQ8NotOnListInd; }
	public void setCbQ8NotOnListInd(String v) { this.cbQ8NotOnListInd = v; }

	public String getCbQ9ReputationInd() { return cbQ9ReputationInd; }
	public void setCbQ9ReputationInd(String v) { this.cbQ9ReputationInd = v; }

	public String getCbQ10InterPlanExecTxt() { return cbQ10InterPlanExecTxt; }
	public void setCbQ10InterPlanExecTxt(String v) { this.cbQ10InterPlanExecTxt = v; }

	public String getCbQ11OtherTxt() { return cbQ11OtherTxt; }
	public void setCbQ11OtherTxt(String v) { this.cbQ11OtherTxt = v; }

	public String getCbQ12TelehealthSvcInd() { return cbQ12TelehealthSvcInd; }
	public void setCbQ12TelehealthSvcInd(String v) { this.cbQ12TelehealthSvcInd = v; }

	public String getCbQ13VirtualOnlyInd() { return cbQ13VirtualOnlyInd; }
	public void setCbQ13VirtualOnlyInd(String v) { this.cbQ13VirtualOnlyInd = v; }

	public String getCbQ16ProviderOutreachInd() { return cbQ16ProviderOutreachInd; }
	public void setCbQ16ProviderOutreachInd(String v) { this.cbQ16ProviderOutreachInd = v; }

	public String getCbQ17ProviderOutreachTxt() { return cbQ17ProviderOutreachTxt; }
	public void setCbQ17ProviderOutreachTxt(String v) { this.cbQ17ProviderOutreachTxt = v; }
