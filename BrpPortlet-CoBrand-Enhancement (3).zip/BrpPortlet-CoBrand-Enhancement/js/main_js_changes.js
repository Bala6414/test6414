/* =============================================================================
File: src/main/webapp/js/main.js
Action: 4 changes in this file.

These changes:
   1. REMOVE the old criteria checkbox handlers (lines 36-118).
   2. UPDATE the showDiv() function (lines 1610-1642) for "Other" trigger and
      to remove the obsolete margin-shifting on the deleted criteriaRequirement
      element.
   3. ADD the new Q1-Q9 cascade + pop-up logic.
   4. ADD the Q11-Q17 IPP cascade logic.
============================================================================= */


/* =============================================================================
CHANGE 1: REMOVE the old criteria checkbox handlers (lines 36-118).

DELETE the entire block starting from:
   //Cobranding Criteria Requirement customisation start
through and including the matching:
   //Cobranding Criteria Requirement customisation end

This removes:
   - Detection of the 5 checkbox elements
   - The 5 checked-state initialization blocks
   - The 5 click handlers ($(document).on('click', '#demoFinancial', ...) etc.)

The block ends just before:
   $.validator.addMethod( 'alpha', ...
============================================================================= */


/* =============================================================================
CHANGE 2: REPLACE the showDiv() function (lines 1611-1640) with the version
          below. Two changes:
            a) "Other" service category now also triggers IPP questions
               (already handled server-side via service_category table flag,
                but we keep the client-side AJAX behavior).
            b) Remove obsolete margin-shifting on #criteriaRequirement
               (that hr is no longer in the JSP).
============================================================================= */

// service Category Questions customisation start
function showDiv(array) {
	AUI().use('aui-io-request',
		function (aui) {
			AUI().io.request($('#serviceCatQuestions').val(), {
				method: 'POST',
				dataType: 'json',
				data: {
					serviceCategoryId: JSON.stringify(array)
				},
				on: {
					success: function () {
						if (this.get('responseData') == true) {
							$("#serviceCatQuestionsFlag").val("Y");
							$("#serviceCategoryQuestions").show();
							// Reset Q11-Q17 cascade visibility based on current Q11 value
							refreshQ11Cascade();
							$("#stateOfIncorporation").css({ 'margin-top': '0px' });
						} else {
							$("#serviceCatQuestionsFlag").val("N");
							$("#serviceCategoryQuestions").hide();
							// Clear cascading IPP question values when section hidden
							clearIppCascade();
							$("#stateOfIncorporation").css({ 'margin-top': '0px' });
						}
					}
				}
			});
		}
	);
}
// service Category Questions customisation end


/* =============================================================================
CHANGE 3: ADD the entire 17-question cascade JS block at the end of main.js.

Append the entire block below to the end of main.js.
============================================================================= */

// =============================================================================
// Co-Branding Partner Form 17-question enhancement start
// =============================================================================

$(document).ready(function () {

	// ----- Date picker for Q2 license agreement date -----
	if ($('#cbQ2LicenseAgmtDt').length) {
		$('#cbQ2LicenseAgmtDt').datepicker({
			numberOfMonths: 1,
			changeMonth: true,
			changeYear: true,
			yearRange: 'c-50:c+50'
		});
	}

	// ----- Q1: Hard-stop pop-up if "No" selected -----
	$(document).on('change', 'input[name="cbQ1LegalNameCnfrmd"]', function () {
		if ($(this).val() === 'N' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ1BlockerDialog');
			// Force unselect so user must change to Yes to proceed
			$('input[name="cbQ1LegalNameCnfrmd"]').prop('checked', false);
		}
	});

	// ----- Q2: Show/hide date field on Yes -----
	$(document).on('change', 'input[name="cbQ2DebitCardInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ2DateBlock').show();
		} else {
			$('#cbQ2DateBlock').hide();
			$('#cbQ2LicenseAgmtDt').val('');
		}
	});

	// ----- Q3: Show/hide acknowledgement checkbox on Yes -----
	$(document).on('change', 'input[name="cbQ3ClientListInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ3AckBlock').show();
		} else {
			$('#cbQ3AckBlock').hide();
			$('input[name="cbQ3ExceptionAckInd"]').prop('checked', false);
		}
	});

	// ----- Q4: Show/hide sub-fields on Yes -----
	$(document).on('change', 'input[name="cbQ4BrandMisuseInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ4Subfields').show();
		} else {
			$('#cbQ4Subfields').hide();
			$('#cbQ4MisuseLinksTxt, #cbQ4MisuseContactTxt').val('');
			$('input[name="cbQ4MisuseAckInd"]').prop('checked', false);
		}
	});

	// ----- Q5: Show/hide sub-fields on Yes -----
	$(document).on('change', 'input[name="cbQ5NameLogoInfrngInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ5Subfields').show();
		} else {
			$('#cbQ5Subfields').hide();
			$('#cbQ5InfrngLinksTxt, #cbQ5InfrngContactTxt').val('');
			$('input[name="cbQ5InfrngAckInd"]').prop('checked', false);
		}
	});

	// ----- Q6: Hard-stop pop-up if "No" -----
	$(document).on('change', 'input[name="cbQ6FinlStableInd"]', function () {
		if ($(this).val() === 'N' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ6BlockerDialog');
			$('input[name="cbQ6FinlStableInd"]').prop('checked', false);
		}
	});

	// ----- Q7: Hard-stop pop-up if "Yes" -----
	$(document).on('change', 'input[name="cbQ7FelonyInd"]', function () {
		if ($(this).val() === 'Y' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ7BlockerDialog');
			$('input[name="cbQ7FelonyInd"]').prop('checked', false);
		}
	});

	// ----- Q8: Show informational note if "No" -----
	$(document).on('change', 'input[name="cbQ8NotOnListInd"]', function () {
		if ($(this).val() === 'N') {
			$('#cbQ8NoteBlock').show();
		} else {
			$('#cbQ8NoteBlock').hide();
		}
	});

	// ----- Q9: Hard-stop pop-up if "Yes" -----
	$(document).on('change', 'input[name="cbQ9ReputationInd"]', function () {
		if ($(this).val() === 'Y' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ9BlockerDialog');
			$('input[name="cbQ9ReputationInd"]').prop('checked', false);
		}
	});

	// ----- Q11: drives Q12-Q17 cascade -----
	$(document).on('change', 'input[name="serviceCategoryBlueBenefit"]', function () {
		refreshQ11Cascade();
	});

	// ----- Q12: drives Q13/Q14/Q15/Q16 -----
	$(document).on('change', 'input[name="cbQ12TelehealthSvcInd"]', function () {
		refreshQ12Cascade();
	});

	// ----- Q13: drives Q14/Q15/Q16 -----
	$(document).on('change', 'input[name="cbQ13VirtualOnlyInd"]', function () {
		refreshQ13Cascade();
	});

	// ----- Q16: drives Q17 -----
	$(document).on('change', 'input[name="cbQ16ProviderOutreachInd"]', function () {
		var v = $('input[name="cbQ16ProviderOutreachInd"]:checked').val();
		if (v === 'Y') {
			$('#cbQ17Block').show();
		} else {
			$('#cbQ17Block').hide();
			$('#cbQ17ProviderOutreachTxt').val('');
		}
	});

	// On page load (e.g., editing a saved-for-later request), restore cascade visibility
	if ($('#serviceCategoryQuestions').is(':visible')) {
		refreshQ11Cascade();
	}
	// Restore Q1-Q9 sub-field visibility based on existing values
	restoreBrandQuestionSubfields();
});

// =============================================================================
// Helper functions
// =============================================================================

function showCbBlockerDialog(dialogSelector) {
	$(dialogSelector).dialog({
		modal: true,
		width: 500,
		buttons: { 'OK': function () { $(this).dialog('close'); } }
	});
}

// Q11 cascade controller - shows correct downstream questions based on Q11 value
function refreshQ11Cascade() {
	var q11 = $('input[name="serviceCategoryBlueBenefit"]:checked').val();

	// Always hide all downstream questions first
	$('#cbQ11OtherBlock').hide();
	$('#cbQ12Block').hide();
	$('#cbQ13Block').hide();
	$('#cbQ14Block').hide();
	$('#cbQ15Block').hide();
	$('#cbQ16Block').hide();
	$('#cbQ17Block').hide();

	if (q11 === 'CARVEOUT') {
		// STOP - no further questions
		clearQ11Other();
		clearQ12to17();
	} else if (q11 === 'CLAIM') {
		clearQ11Other();
		$('#cbQ12Block').show();
		refreshQ12Cascade();
	} else if (q11 === 'OTHER') {
		$('#cbQ11OtherBlock').show();
		// Q11=OTHER -> jump to Q14, Q15, Q16
		$('#cbQ14Block').show();
		$('#cbQ15Block').show();
		$('#cbQ16Block').show();
		// Q17 visibility depends on Q16 - restore if user already answered Q16=Yes
		if ($('input[name="cbQ16ProviderOutreachInd"]:checked').val() === 'Y') {
			$('#cbQ17Block').show();
		}
	}
}

// Q12 cascade
function refreshQ12Cascade() {
	var q12 = $('input[name="cbQ12TelehealthSvcInd"]:checked').val();
	$('#cbQ13Block').hide();
	$('#cbQ14Block').hide();
	$('#cbQ15Block').hide();
	$('#cbQ16Block').hide();
	$('#cbQ17Block').hide();

	if (q12 === 'Y') {
		$('#cbQ13Block').show();
		refreshQ13Cascade();
	} else if (q12 === 'N') {
		// Q12=No -> Q14, Q15, Q16
		$('#cbQ14Block').show();
		$('#cbQ15Block').show();
		$('#cbQ16Block').show();
		if ($('input[name="cbQ16ProviderOutreachInd"]:checked').val() === 'Y') {
			$('#cbQ17Block').show();
		}
	}
}

// Q13 cascade
function refreshQ13Cascade() {
	var q13 = $('input[name="cbQ13VirtualOnlyInd"]:checked').val();
	$('#cbQ14Block').hide();
	$('#cbQ15Block').hide();
	$('#cbQ16Block').hide();
	$('#cbQ17Block').hide();

	if (q13 === 'Y') {
		// STOP - virtual only
	} else if (q13 === 'N') {
		// Q13=No (in-person also) -> Q14, Q15, Q16
		$('#cbQ14Block').show();
		$('#cbQ15Block').show();
		$('#cbQ16Block').show();
		if ($('input[name="cbQ16ProviderOutreachInd"]:checked').val() === 'Y') {
			$('#cbQ17Block').show();
		}
	}
}

function clearQ11Other() {
	$('#cbQ11OtherTxt').val('');
}

function clearQ12to17() {
	$('input[name="cbQ12TelehealthSvcInd"]').prop('checked', false);
	$('input[name="cbQ13VirtualOnlyInd"]').prop('checked', false);
	$('input[name="serviceCategoryNationalAccountMember"]').prop('checked', false);
	$('#serviceCategoryServiceEntail').val('');
	$('input[name="cbQ16ProviderOutreachInd"]').prop('checked', false);
	$('#cbQ17ProviderOutreachTxt').val('');
}

function clearIppCascade() {
	$('#cbQ10InterPlanExecTxt').val('');
	$('input[name="serviceCategoryBlueBenefit"]').prop('checked', false);
	clearQ11Other();
	clearQ12to17();
}

// On page load, restore visibility of Q1-Q9 sub-fields based on saved values
function restoreBrandQuestionSubfields() {
	if ($('input[name="cbQ2DebitCardInd"]:checked').val() === 'Y') {
		$('#cbQ2DateBlock').show();
	}
	if ($('input[name="cbQ3ClientListInd"]:checked').val() === 'Y') {
		$('#cbQ3AckBlock').show();
	}
	if ($('input[name="cbQ4BrandMisuseInd"]:checked').val() === 'Y') {
		$('#cbQ4Subfields').show();
	}
	if ($('input[name="cbQ5NameLogoInfrngInd"]:checked').val() === 'Y') {
		$('#cbQ5Subfields').show();
	}
	if ($('input[name="cbQ8NotOnListInd"]:checked').val() === 'N') {
		$('#cbQ8NoteBlock').show();
	}
}

// =============================================================================
// Co-Branding Partner Form 17-question enhancement end
// =============================================================================
