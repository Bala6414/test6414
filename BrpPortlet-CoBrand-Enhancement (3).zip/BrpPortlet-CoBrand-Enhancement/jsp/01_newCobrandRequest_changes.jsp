<%-- ============================================================================
File: src/main/webapp/WEB-INF/jsp/BrpPortlet/newCobrandRequest.jsp
Action: 3 changes in this file.
============================================================================ --%>


<%-- ============================================================================
CHANGE 1: REMOVE the existing service-category-questions block AND the
          Cobranding Criteria Requirements block.
          REPLACE with the new Q1-Q9 (always shown) + Q10-Q17 (IPP triggered)
          structure.

REMOVE LINES 315 through 366 (the entire existing block from
   <!-- service category questions customisation start -->
through
   <!-- Cobranding Criteria Requirement customisation end  -->).

REPLACE WITH the markup BELOW (between BEGIN/END markers).
============================================================================ --%>

<%-- ============================ BEGIN REPLACEMENT MARKUP ===================== --%>

		<!-- Co-Branding Partner Form 17-question enhancement start -->
		<input type="hidden" id="serviceCatQuestions" name="<portlet:namespace />serviceCatQuestions" value="${serviceCatQuestions}">
		<input type="hidden" id="serviceCatQuestionsFlag" name="<portlet:namespace />serviceCatQuestionsFlag" value="${empty brandrequest.serviceCatQuestionsFlag ? 'N' : brandrequest.serviceCatQuestionsFlag}">

		<hr />
		<h4>Brand Questions <liferay-ui:icon-help message="The following questions must be answered for all Co-Branding requests." /></h4>

		<%-- ===== Q1: Legal name confirmed ===== --%>
		<div class="control-group cb-question" id="cbQ1Block">
			<label class="field_header">1. Have you confirmed the legal name of this entity (e.g., via secretary of state databases, Dun and Bradstreet, or publicly available government filings) and that any listed trade names are not those of a separately formed legal entity (e.g., has a separate record with a secretary of state or a separate DUNS number)?</label>
			<form:errors path="cbQ1LegalNameCnfrmd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ1LegalNameCnfrmd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ1LegalNameCnfrmd" value="N" />&nbsp;No</label>
		</div>

		<%-- ===== Q2: Brands on debit / reward card ===== --%>
		<div class="control-group cb-question" id="cbQ2Block">
			<label class="field_header">2. Will this solution result in the Brands appearing on a debit card or reward card?</label>
			<form:errors path="cbQ2DebitCardInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ2DebitCardInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ2DebitCardInd" value="N" />&nbsp;No</label>
			<div id="cbQ2DateBlock" class="cb-subfield" style="margin-top:8px; display:none;">
				<label>Date BCBSA confirmed the license agreement, or date application was sent to BCBSA: <span class="req">*</span></label>
				<form:errors path="cbQ2LicenseAgmtDt" cssClass="errorspanCss" element="div" />
				<form:input path="cbQ2LicenseAgmtDt" id="cbQ2LicenseAgmtDt" placeholder="MM/DD/YYYY" />
			</div>
		</div>

		<%-- ===== Q3: Brands in client list / testimonial ===== --%>
		<div class="control-group cb-question" id="cbQ3Block">
			<label class="field_header">3. Will this solution result in the Brands appearing in a client list (other than those permitted under chapter 4 of the Brand Regulations) or testimonial on behalf of your Plan?</label>
			<form:errors path="cbQ3ClientListInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ3ClientListInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ3ClientListInd" value="N" />&nbsp;No</label>
			<div id="cbQ3AckBlock" class="cb-subfield" style="margin-top:8px; display:none;">
				<form:errors path="cbQ3ExceptionAckInd" cssClass="errorspanCss" element="div" />
				<label class="checkbox">
					<form:checkbox path="cbQ3ExceptionAckInd" value="Y" />
					Our Plan understands that the Brand Regulations do not permit the Brands to appear in testimonials or client lists outside of our service area (unless solely used with other Blue Licensees). We are requesting BCBSA to review an exception for this request.
				</label>
			</div>
		</div>

		<%-- ===== Q4: Possible Brand misuse located ===== --%>
		<div class="control-group cb-question" id="cbQ4Block">
			<label class="field_header">4. During your review of this company, did you locate any possible misuse of the Brands that you would like BCBSA to review or assist with resolving?</label>
			<form:errors path="cbQ4BrandMisuseInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ4BrandMisuseInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ4BrandMisuseInd" value="N" />&nbsp;No</label>
			<div id="cbQ4Subfields" class="cb-subfield" style="margin-top:8px; display:none;">
				<label>Please provide links to the possible misuse: <span class="req">*</span></label>
				<form:errors path="cbQ4MisuseLinksTxt" cssClass="errorspanCss" element="div" />
				<form:textarea path="cbQ4MisuseLinksTxt" id="cbQ4MisuseLinksTxt" cssClass="span12" rows="5"></form:textarea>
				<label>Please provide a contact name and email address for a contact at the company we can reach out to in order to resolve this matter: <span class="req">*</span></label>
				<form:errors path="cbQ4MisuseContactTxt" cssClass="errorspanCss" element="div" />
				<form:textarea path="cbQ4MisuseContactTxt" id="cbQ4MisuseContactTxt" cssClass="span12" rows="5"></form:textarea>
				<form:errors path="cbQ4MisuseAckInd" cssClass="errorspanCss" element="div" />
				<label class="checkbox">
					<form:checkbox path="cbQ4MisuseAckInd" value="Y" />
					Our Plan understands that BCBSA will review the report and take action, if required. If misuse is confirmed by BCBSA, we understand the request will not be processed until such misuse is resolved.
				</label>
			</div>
		</div>

		<%-- ===== Q5: Name / logo / slogan infringement ===== --%>
		<div class="control-group cb-question" id="cbQ5Block">
			<label class="field_header">5. Does the company's name, logo or slogan include elements (e.g., a blue cross or shield design, the word "blue," etc.) that is likely to infringe on or impact the goodwill of the Brands?</label>
			<form:errors path="cbQ5NameLogoInfrngInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ5NameLogoInfrngInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ5NameLogoInfrngInd" value="N" />&nbsp;No</label>
			<div id="cbQ5Subfields" class="cb-subfield" style="margin-top:8px; display:none;">
				<label>Please provide a link showing the name, logo or slogan: <span class="req">*</span></label>
				<form:errors path="cbQ5InfrngLinksTxt" cssClass="errorspanCss" element="div" />
				<form:textarea path="cbQ5InfrngLinksTxt" id="cbQ5InfrngLinksTxt" cssClass="span12" rows="5"></form:textarea>
				<label>Please provide a contact name and email address for a contact at the company we can reach out to in order to resolve this matter: <span class="req">*</span></label>
				<form:errors path="cbQ5InfrngContactTxt" cssClass="errorspanCss" element="div" />
				<form:textarea path="cbQ5InfrngContactTxt" id="cbQ5InfrngContactTxt" cssClass="span12" rows="5"></form:textarea>
				<form:errors path="cbQ5InfrngAckInd" cssClass="errorspanCss" element="div" />
				<label class="checkbox">
					<form:checkbox path="cbQ5InfrngAckInd" value="Y" />
					Our Plan understands that BCBSA will review the report and take action, if required. If the report is confirmed by BCBSA, we understand the request will not be processed until such misuse is resolved.
				</label>
			</div>
		</div>

		<%-- ===== Q6: Financial stability ===== --%>
		<div class="control-group cb-question" id="cbQ6Block">
			<label class="field_header">6. To the best of your knowledge, is the company financially stable as outlined in the Brand Regulations?</label>
			<form:errors path="cbQ6FinlStableInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ6FinlStableInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ6FinlStableInd" value="N" />&nbsp;No</label>
		</div>

		<%-- ===== Q7: Felony conviction ===== --%>
		<div class="control-group cb-question" id="cbQ7Block">
			<label class="field_header">7. To the best of your knowledge, has the company been convicted of a felony within the past three years?</label>
			<form:errors path="cbQ7FelonyInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ7FelonyInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ7FelonyInd" value="N" />&nbsp;No</label>
		</div>

		<%-- ===== Q8: Not on disapproved / competitor list ===== --%>
		<div class="control-group cb-question" id="cbQ8Block">
			<label class="field_header">8. Have you confirmed that the company is not on one of the lists (e.g., disapproved, national competitor or primary brand of a national competitor) which prevents the company from co-branding?</label>
			<form:errors path="cbQ8NotOnListInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ8NotOnListInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ8NotOnListInd" value="N" />&nbsp;No</label>
			<div id="cbQ8NoteBlock" class="cb-subfield" style="margin-top:8px; display:none;">
				<span class="note">The company appears on one or more of the lists, but they are solely providing PBM services or an exception has been documented with BCBSA. You may proceed.</span>
			</div>
		</div>

		<%-- ===== Q9: Reputation could dilute / tarnish ===== --%>
		<div class="control-group cb-question" id="cbQ9Block">
			<label class="field_header">9. In your reasonable business judgement, does the company have a reputation that would dilute or tarnish the value of the Brands?</label>
			<form:errors path="cbQ9ReputationInd" cssClass="errorspanCss" element="div" />
			<label class="radio inline"><form:radiobutton path="cbQ9ReputationInd" value="Y" />&nbsp;Yes</label>
			<label class="radio inline"><form:radiobutton path="cbQ9ReputationInd" value="N" />&nbsp;No</label>
		</div>

		<hr />

		<!-- ===== Q10-Q17: Inter-Plan Policy questions (shown only when triggered by service category) ===== -->
		<div id="serviceCategoryQuestions" style="display:none;">
			<h4>Inter-Plan Policy <liferay-ui:icon-help message="The following questions appear when one or more Inter-Plan Policy service categories are selected." /></h4>

			<%-- ===== Q10: Inter-Plan Executive ===== --%>
			<div class="control-group cb-question" id="cbQ10Block">
				<label class="field_header">10. Please provide the name of the Inter-Plan Executive or member of your Plan's Inter-Plan team who reviewed this request for compliance with Inter-Plan Policies and Provisions.</label>
				<form:errors path="cbQ10InterPlanExecTxt" cssClass="errorspanCss" element="div" />
				<form:textarea path="cbQ10InterPlanExecTxt" id="cbQ10InterPlanExecTxt" cssClass="span12" rows="3"></form:textarea>
			</div>

			<%-- ===== Q11: Carveout / Claim / Other ===== --%>
			<div class="control-group cb-question" id="cbQ11Block">
				<label class="field_header">11. Do these services generate a claim against the member's Blue benefits or is this a carveout? For purposes of this request, carveout means the benefits are not Blue, the member would not present their BCBS ID card when seeking services, and there are no claims filed/processed against the member's Blue benefits.</label>
				<form:errors path="serviceCategoryBlueBenefit" cssClass="errorspanCss" element="div" />
				<label class="radio"><form:radiobutton path="serviceCategoryBlueBenefit" value="CARVEOUT" />&nbsp;Carveout</label>
				<label class="radio"><form:radiobutton path="serviceCategoryBlueBenefit" value="CLAIM" />&nbsp;Generates a claim against the member's Blue benefits</label>
				<label class="radio"><form:radiobutton path="serviceCategoryBlueBenefit" value="OTHER" />&nbsp;Other (please describe)</label>
				<div id="cbQ11OtherBlock" class="cb-subfield" style="margin-top:8px; display:none;">
					<label>Please describe: <span class="req">*</span></label>
					<form:errors path="cbQ11OtherTxt" cssClass="errorspanCss" element="div" />
					<form:textarea path="cbQ11OtherTxt" id="cbQ11OtherTxt" cssClass="span12" rows="5"></form:textarea>
				</div>
			</div>

			<%-- ===== Q12: Clinical telehealth ===== --%>
			<div class="control-group cb-question" id="cbQ12Block" style="display:none;">
				<label class="field_header">12. If the services generate a claim against the member's Blue benefits, is this a clinical telehealth service or solution (e.g., behavioral health or primary care)?</label>
				<form:errors path="cbQ12TelehealthSvcInd" cssClass="errorspanCss" element="div" />
				<label class="radio inline"><form:radiobutton path="cbQ12TelehealthSvcInd" value="Y" />&nbsp;Yes</label>
				<label class="radio inline"><form:radiobutton path="cbQ12TelehealthSvcInd" value="N" />&nbsp;No</label>
			</div>

			<%-- ===== Q13: Virtual only ===== --%>
			<div class="control-group cb-question" id="cbQ13Block" style="display:none;">
				<label class="field_header">13. If this is a clinical telehealth service or solution (e.g., behavioral health or primary care), are the services virtual only?</label>
				<form:errors path="cbQ13VirtualOnlyInd" cssClass="errorspanCss" element="div" />
				<label class="radio inline"><form:radiobutton path="cbQ13VirtualOnlyInd" value="Y" />&nbsp;Yes, this is a virtual only telehealth service or solution.</label>
				<label class="radio inline"><form:radiobutton path="cbQ13VirtualOnlyInd" value="N" />&nbsp;No, the service or solution includes the option for in-person services.</label>
			</div>

			<%-- ===== Q14: Available outside Plan service area ===== --%>
			<div class="control-group cb-question" id="cbQ14Block" style="display:none;">
				<label class="field_header">14. Is this program/service available to your national account members that reside outside of your Plans service area?</label>
				<form:errors path="serviceCategoryNationalAccountMember" cssClass="errorspanCss" element="div" />
				<label class="radio inline"><form:radiobutton path="serviceCategoryNationalAccountMember" value="Y" />&nbsp;Yes</label>
				<label class="radio inline"><form:radiobutton path="serviceCategoryNationalAccountMember" value="N" />&nbsp;No</label>
			</div>

			<%-- ===== Q15: What do services entail ===== --%>
			<div class="control-group cb-question" id="cbQ15Block" style="display:none;">
				<label class="field_header">15. What do the services entail? Please provide as much detail as possible.</label>
				<form:errors path="serviceCategoryServiceEntail" cssClass="errorspanCss" element="div" />
				<form:textarea path="serviceCategoryServiceEntail" id="serviceCategoryServiceEntail" cssClass="span12" rows="5"></form:textarea>
			</div>

			<%-- ===== Q16: Outreach to providers outside Plan area ===== --%>
			<div class="control-group cb-question" id="cbQ16Block" style="display:none;">
				<label class="field_header">16. Does this solution include outreach to providers outside of your service area?</label>
				<form:errors path="cbQ16ProviderOutreachInd" cssClass="errorspanCss" element="div" />
				<label class="radio inline"><form:radiobutton path="cbQ16ProviderOutreachInd" value="Y" />&nbsp;Yes</label>
				<label class="radio inline"><form:radiobutton path="cbQ16ProviderOutreachInd" value="N" />&nbsp;No</label>
			</div>

			<%-- ===== Q17: What does provider outreach entail ===== --%>
			<div class="control-group cb-question" id="cbQ17Block" style="display:none;">
				<label class="field_header">17. If this solution includes outreach to providers outside of your service area, what does this provider outreach entail? Please provide as much detail as possible.</label>
				<form:errors path="cbQ17ProviderOutreachTxt" cssClass="errorspanCss" element="div" />
				<form:textarea path="cbQ17ProviderOutreachTxt" id="cbQ17ProviderOutreachTxt" cssClass="span12" rows="5"></form:textarea>
			</div>
		</div>

		<hr />
		<!-- Co-Branding Partner Form 17-question enhancement end -->

<%-- ============================ END REPLACEMENT MARKUP ===================== --%>


<%-- ============================================================================
CHANGE 2: REMOVE the Group Account Type block (lines 562-575).

DELETE EXACTLY THIS BLOCK:

   <br />
   <label class="field_header">Choose Group Account Type <liferay-ui:icon-help message="Will this partner serve Commercial Business, Labor, or Both?" /></label>
   <c:if test="${saveAs ne 'new' || empty brandrequest.brandRqstUid}">
   <form:errors path="groupAccountType" cssClass="errorspanCss" element="div" />
   <form:select path="groupAccountType.grpAcctTypCd">
       <form:option value="0">Choose One</form:option>
       <form:options items="${groupAccountTypes}" itemLabel="grpAcctTypDesc" itemValue="grpAcctTypCd"/>
   </form:select>
   </c:if>
   <c:if test="${saveAs eq 'new'}">
   <form:select path="groupAccountType.grpAcctTypCd" readonly="true">
       <form:options items="${groupAccountTypes}" itemLabel="grpAcctTypDesc" itemValue="grpAcctTypCd"/>
   </form:select>
   </c:if>
   <br />

(Leave the surrounding markup intact: "Is the company a Third Party Administrator (TPA)?"
section just below this remains unchanged.)
============================================================================ --%>


<%-- ============================================================================
CHANGE 3: ADD pop-up modal containers near the end of the JSP, just BEFORE
          the existing dialog containers (around line 745, where
          "attachment-cobrand-dialog", "delete-confirmation",
          "coBrandDiscardReqDialog" are defined).

ADD this markup:
============================================================================ --%>

<%-- ===== Pop-up blocker dialogs ===== --%>
<div id="cbQ1BlockerDialog" title="Co-Branding Request" class="hiddenDefault">
	Co-branding requests should use the legal name of the co-branding partner. Separate requests are required for each entity appearing in co-branded communications. Users should not be able to move forward without selecting yes.
</div>

<div id="cbQ6BlockerDialog" title="Co-Branding Request" class="hiddenDefault">
	Co-branding partners are required to be financially stable per the Brand Regulations. The request cannot proceed.
</div>

<div id="cbQ7BlockerDialog" title="Co-Branding Request" class="hiddenDefault">
	Co-branding partners cannot have been convicted of a felony in the past three years. The request cannot proceed.
</div>

<div id="cbQ9BlockerDialog" title="Co-Branding Request" class="hiddenDefault">
	Co-branding partners may not have a reputation that would dilute or tarnish the value of the Brands. The request cannot proceed.
</div>
