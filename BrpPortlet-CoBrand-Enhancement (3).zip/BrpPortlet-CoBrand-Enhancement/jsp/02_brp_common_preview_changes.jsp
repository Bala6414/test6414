<%-- ============================================================================
File: src/main/webapp/WEB-INF/jsp/BrpPortlet/brp-common-preview.jsp
Action: 3 changes in this file.

This JSP is used to display submitted Co-Branding Requests on the review and
preview screens. It must show:
   - For NEW records: the Q1-Q9 brand questions and Q10-Q17 IPP questions.
   - For LEGACY records: the old criteria checkboxes and Group Account Type
     (so historical submissions remain viewable). New records will not have
     these fields populated.
============================================================================ --%>


<%-- ============================================================================
CHANGE 1: REPLACE the existing service-category-questions block (lines 66-88)
          with the new Q1-Q17 display block.

REMOVE LINES 66 through 88 (the entire <c:if test="${brandrequest.serviceCatQuestionsFlag=='Y'}"> block).

REPLACE WITH the markup BELOW.
============================================================================ --%>

<%-- ===== BEGIN: New Q1-Q17 display block ===== --%>

<%-- Q1-Q9 Brand Questions: shown only for NEW records (Q1 indicator presence
     means it's a new-style record with the 17-question structure) --%>
<c:if test="${not empty brandrequest.cbQ1LegalNameCnfrmd}">
	<h4>1. Have you confirmed the legal name of this entity?</h4>
	${brandrequest.cbQ1LegalNameCnfrmd == 'Y' ? 'Yes' : 'No'}
	<br /><hr />

	<h4>2. Will this solution result in the Brands appearing on a debit card or reward card?</h4>
	${brandrequest.cbQ2DebitCardInd == 'Y' ? 'Yes' : 'No'}
	<c:if test="${brandrequest.cbQ2DebitCardInd == 'Y' and not empty brandrequest.cbQ2LicenseAgmtDt}">
		<br />Date BCBSA confirmed the license agreement / application sent: ${brandrequest.cbQ2LicenseAgmtDt}
	</c:if>
	<br /><hr />

	<h4>3. Will this solution result in the Brands appearing in a client list or testimonial?</h4>
	${brandrequest.cbQ3ClientListInd == 'Y' ? 'Yes' : 'No'}
	<c:if test="${brandrequest.cbQ3ClientListInd == 'Y' and brandrequest.cbQ3ExceptionAckInd == 'Y'}">
		<br /><em>Plan acknowledged exception review.</em>
	</c:if>
	<br /><hr />

	<h4>4. During your review, did you locate any possible misuse of the Brands?</h4>
	${brandrequest.cbQ4BrandMisuseInd == 'Y' ? 'Yes' : 'No'}
	<c:if test="${brandrequest.cbQ4BrandMisuseInd == 'Y'}">
		<br /><strong>Links to misuse:</strong><br />${brandrequest.cbQ4MisuseLinksTxt}
		<br /><strong>Contact name and email:</strong><br />${brandrequest.cbQ4MisuseContactTxt}
		<c:if test="${brandrequest.cbQ4MisuseAckInd == 'Y'}">
			<br /><em>Plan acknowledged BCBSA review.</em>
		</c:if>
	</c:if>
	<br /><hr />

	<h4>5. Does the company's name, logo or slogan include elements likely to infringe on the Brands?</h4>
	${brandrequest.cbQ5NameLogoInfrngInd == 'Y' ? 'Yes' : 'No'}
	<c:if test="${brandrequest.cbQ5NameLogoInfrngInd == 'Y'}">
		<br /><strong>Link showing name/logo/slogan:</strong><br />${brandrequest.cbQ5InfrngLinksTxt}
		<br /><strong>Contact name and email:</strong><br />${brandrequest.cbQ5InfrngContactTxt}
		<c:if test="${brandrequest.cbQ5InfrngAckInd == 'Y'}">
			<br /><em>Plan acknowledged BCBSA review.</em>
		</c:if>
	</c:if>
	<br /><hr />

	<h4>6. To the best of your knowledge, is the company financially stable?</h4>
	${brandrequest.cbQ6FinlStableInd == 'Y' ? 'Yes' : 'No'}
	<br /><hr />

	<h4>7. Has the company been convicted of a felony within the past three years?</h4>
	${brandrequest.cbQ7FelonyInd == 'Y' ? 'Yes' : 'No'}
	<br /><hr />

	<h4>8. Have you confirmed the company is not on a disapproved or competitor list?</h4>
	${brandrequest.cbQ8NotOnListInd == 'Y' ? 'Yes' : 'No'}
	<br /><hr />

	<h4>9. Does the company have a reputation that would dilute or tarnish the Brands?</h4>
	${brandrequest.cbQ9ReputationInd == 'Y' ? 'Yes' : 'No'}
	<br /><hr />
</c:if>

<%-- Q10-Q17 IPP Questions: shown only when serviceCatQuestionsFlag = Y
     This block handles BOTH new (radio) and legacy (textarea) data via the
     value comparison on serviceCategoryBlueBenefit.
     For legacy records: serviceCategoryBlueBenefit holds free text.
     For new records: serviceCategoryBlueBenefit holds CARVEOUT, CLAIM, or OTHER. --%>
<c:if test="${brandrequest.serviceCatQuestionsFlag == 'Y'}">
	<%-- New-style record: shows Q10 only if it has data --%>
	<c:if test="${not empty brandrequest.cbQ10InterPlanExecTxt}">
		<h4>10. Inter-Plan Executive / Plan IPP team contact</h4>
		${brandrequest.cbQ10InterPlanExecTxt}
		<br /><hr />
	</c:if>

	<h4>11. Do these services generate a claim against the member's Blue benefits or is this a carveout?</h4>
	<c:choose>
		<c:when test="${brandrequest.serviceCategoryBlueBenefit == 'CARVEOUT'}">Carveout</c:when>
		<c:when test="${brandrequest.serviceCategoryBlueBenefit == 'CLAIM'}">Generates a claim against the member's Blue benefits</c:when>
		<c:when test="${brandrequest.serviceCategoryBlueBenefit == 'OTHER'}">Other - ${brandrequest.cbQ11OtherTxt}</c:when>
		<c:otherwise>${brandrequest.serviceCategoryBlueBenefit}</c:otherwise>
	</c:choose>
	<br /><hr />

	<%-- Q12-Q13: shown only for new-style records with values --%>
	<c:if test="${not empty brandrequest.cbQ12TelehealthSvcInd}">
		<h4>12. Is this a clinical telehealth service or solution?</h4>
		${brandrequest.cbQ12TelehealthSvcInd == 'Y' ? 'Yes' : 'No'}
		<br /><hr />
	</c:if>
	<c:if test="${not empty brandrequest.cbQ13VirtualOnlyInd}">
		<h4>13. Are the telehealth services virtual only?</h4>
		${brandrequest.cbQ13VirtualOnlyInd == 'Y' ? 'Yes' : 'No'}
		<br /><hr />
	</c:if>

	<%-- Q14: reuses existing serviceCategoryNationalAccountMember (Y/N for new, free text for legacy) --%>
	<c:if test="${not empty brandrequest.serviceCategoryNationalAccountMember}">
		<h4>14. Is this program/service available to your national account members that reside outside of your Plans service area?</h4>
		<c:choose>
			<c:when test="${brandrequest.serviceCategoryNationalAccountMember == 'Y'}">Yes</c:when>
			<c:when test="${brandrequest.serviceCategoryNationalAccountMember == 'N'}">No</c:when>
			<c:otherwise>${brandrequest.serviceCategoryNationalAccountMember}</c:otherwise>
		</c:choose>
		<br /><hr />
	</c:if>

	<%-- Q15: reuses existing serviceCategoryServiceEntail (free text - same for new and legacy) --%>
	<c:if test="${not empty brandrequest.serviceCategoryServiceEntail}">
		<h4>15. What do the services entail?</h4>
		${brandrequest.serviceCategoryServiceEntail}
		<br /><hr />
	</c:if>

	<%-- Q16-Q17: new fields only --%>
	<c:if test="${not empty brandrequest.cbQ16ProviderOutreachInd}">
		<h4>16. Does this solution include outreach to providers outside of your service area?</h4>
		${brandrequest.cbQ16ProviderOutreachInd == 'Y' ? 'Yes' : 'No'}
		<br /><hr />
	</c:if>
	<c:if test="${brandrequest.cbQ16ProviderOutreachInd == 'Y' and not empty brandrequest.cbQ17ProviderOutreachTxt}">
		<h4>17. What does the provider outreach entail?</h4>
		${brandrequest.cbQ17ProviderOutreachTxt}
		<br /><hr />
	</c:if>
</c:if>

<%-- ===== END: New Q1-Q17 display block ===== --%>


<%-- ============================================================================
CHANGE 2: WRAP the legacy criteria block (lines 90-132) with a c:if so it
          only shows for legacy records.

FIND THIS BLOCK (lines 90-132):
   <!-- Cobranding Criteria Requirement customisation start -->
   <h4>Demonstrate Financial Stability</h4>
   <c:if test="${brandrequest.demoFinancial =='Y'}">Yes</c:if>
   ...
   ...all 5 checkbox display blocks...
   <!-- Cobranding Criteria Requirement customisation end -->

REPLACE WITH (just adds the outer c:if and tweaks the "Yes" handling so that
"No" responses also display, like the original code intent):
============================================================================ --%>

<%-- Legacy Cobranding Criteria - shown only when legacy data present
     (i.e., new Q1 indicator is empty meaning it's an old-style record) --%>
<c:if test="${empty brandrequest.cbQ1LegalNameCnfrmd and (brandrequest.demoFinancial == 'Y' or brandrequest.noFelonyRecord == 'Y' or brandrequest.reputationBrand == 'Y' or brandrequest.prohibitatedCompany == 'Y' or brandrequest.noMisuseOfBrands == 'Y')}">
	<!-- Legacy Cobranding Criteria Requirement display start -->
	<h4>Demonstrate Financial Stability</h4>
	<c:if test="${brandrequest.demoFinancial =='Y'}">Yes</c:if>
	<br /><hr />
	<h4>No Felony Record</h4>
	<c:if test="${brandrequest.noFelonyRecord =='Y'}">Yes</c:if>
	<br /><hr />
	<h4>Reputation Brand</h4>
	<c:if test="${brandrequest.reputationBrand =='Y'}">Yes</c:if>
	<br /><hr />
	<h4>Prohibited Company</h4>
	<c:if test="${brandrequest.prohibitatedCompany =='Y'}">Yes</c:if>
	<br /><hr />
	<h4>No Misuse of Brands</h4>
	<c:if test="${brandrequest.noMisuseOfBrands =='Y'}">Yes</c:if>
	<br /><hr />
	<!-- Legacy Cobranding Criteria Requirement display end -->
</c:if>


<%-- ============================================================================
CHANGE 3: WRAP the Group Account Type display (lines 199-204) with a c:if
          so it only shows when present (legacy records).

FIND THIS BLOCK (lines 199-204):
   <h4>Choose Group Account Type</h4>
   ${brandrequest.groupAccountType.grpAcctTypDesc}
   <br />
   <hr />

REPLACE WITH:
============================================================================ --%>

<%-- Group Account Type - shown only for legacy records with this field populated --%>
<c:if test="${not empty brandrequest.groupAccountType.grpAcctTypDesc}">
	<h4>Choose Group Account Type</h4>
	${brandrequest.groupAccountType.grpAcctTypDesc}
	<br /><hr />
</c:if>
