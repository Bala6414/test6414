# BlueWeb Co-Branding Partner Form 17-Question Enhancement

## Just two folders. That's it.

```
ddl/    Run these SQL scripts on DB (in order)
src/    Drop these files over your project tree
```

## Steps

### 1. Database
Run on DEV first, then QA, then PROD:

```
ddl/01_alter_brand_request_add_questions.sql      → adds 23 new columns
ddl/02_update_other_service_category.sql          → flips "Other" to trigger IPP
```

### 2. Code
Drop the files in `src/` directly over the same paths in your BrpPortlet workspace:

```
src/main/java/com/bcbsa/brp/model/BrandRequest.java
src/main/java/com/bcbsa/brp/vo/BrandRequestVo.java
src/main/java/com/bcbsa/brp/model/util/BrandRequestVoMapper.java
src/main/java/com/bcbsa/brp/validation/BrpCobrandingFormValidator.java
src/main/java/com/bcbsa/brp/service/impl/BrandRequestServiceImpl.java
src/main/resources/messages.properties
src/main/webapp/WEB-INF/jsp/BrpPortlet/newCobrandRequest.jsp
src/main/webapp/WEB-INF/jsp/BrpPortlet/brp-common-preview.jsp
src/main/webapp/js/main.js
```

### 3. Build & deploy
```
gradle clean build
```
Then deploy the WAR to DEV Tomcat.
