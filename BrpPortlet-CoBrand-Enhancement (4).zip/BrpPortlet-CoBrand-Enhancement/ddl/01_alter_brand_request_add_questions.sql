-- =============================================================================
-- BlueWeb Co-Branding Partner Form Enhancement
-- DDL: Add 17-question fields to brand_request table (SQL Server)
-- =============================================================================
-- Conventions matched from existing brand_request columns:
--   * Free-text columns: VARCHAR(MAX) NULL
--     (matches BRAND_USAGE_DESC, SRVC_BLUE_BENEFITS,
--      SRVC_NATIONAL_ACCOUNT_MEMBERS, SRVC_SERVICES_ENTAIL)
--   * Y/N indicator columns: CHAR(1) NULL
--     (matches DEMO_FINANCIAL, NO_FELONY_RECORD)
--
-- Notes:
--   * Old criteria checkbox columns (DEMO_FINANCIAL, NO_FELONY_RECORD,
--     REPUTATION_BRANDS, PROHIBITED_CPMNY, NO_MISUSE_OF_BRANDS) are NOT dropped.
--     Legacy records remain viewable in My History / Workqueue.
--   * Existing columns SRVC_BLUE_BENEFITS, SRVC_NATIONAL_ACCOUNT_MEMBERS,
--     SRVC_SERVICES_ENTAIL are REUSED for Q11, Q14, Q15 respectively.
--   * Run this against DEV first, then QA, then PROD.
--   * Make sure your session is connected to the correct database before running.
-- =============================================================================

-- USE [your_database_name];
-- GO

-- ----------------------------------------------------------------------------
-- Q1: Have you confirmed the legal name?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q1_LEGAL_NAME_CNFRMD CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q2: Brands appearing on debit/reward card?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q2_DEBIT_CARD_IND CHAR(1) NULL;
GO

ALTER TABLE brand_request ADD CB_Q2_LICENSE_AGMT_DT VARCHAR(20) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q3: Brands in client list / testimonial?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q3_CLIENT_LIST_IND CHAR(1) NULL;
GO

ALTER TABLE brand_request ADD CB_Q3_EXCEPTION_ACK_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q4: Possible Brand misuse located?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q4_BRAND_MISUSE_IND CHAR(1) NULL;
GO

ALTER TABLE brand_request ADD CB_Q4_MISUSE_LINKS_TXT VARCHAR(MAX) NULL;
GO

ALTER TABLE brand_request ADD CB_Q4_MISUSE_CONTACT_TXT VARCHAR(MAX) NULL;
GO

ALTER TABLE brand_request ADD CB_Q4_MISUSE_ACK_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q5: Company name / logo / slogan infringement?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q5_NAME_LOGO_INFRNG_IND CHAR(1) NULL;
GO

ALTER TABLE brand_request ADD CB_Q5_INFRNG_LINKS_TXT VARCHAR(MAX) NULL;
GO

ALTER TABLE brand_request ADD CB_Q5_INFRNG_CONTACT_TXT VARCHAR(MAX) NULL;
GO

ALTER TABLE brand_request ADD CB_Q5_INFRNG_ACK_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q6: Financially stable?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q6_FINL_STABLE_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q7: Felony conviction in last 3 years?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q7_FELONY_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q8: Not on disapproved / national competitor list?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q8_NOT_ON_LIST_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q9: Reputation could dilute/tarnish Brands?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q9_REPUTATION_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q10: Inter-Plan Executive name (IPP question - shown when triggering categories selected)
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q10_INTER_PLAN_EXEC_TXT VARCHAR(MAX) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q11: Carveout / Generates a Claim / Other?
-- REUSING existing column SRVC_BLUE_BENEFITS to store the radio value:
--    "CARVEOUT" | "CLAIM" | "OTHER"
-- Old records may still contain free text in this column - that is fine.
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q11_OTHER_TXT VARCHAR(MAX) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q12: Clinical telehealth service / solution?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q12_TELEHEALTH_SVC_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q13: Virtual only?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q13_VIRTUAL_ONLY_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q14: Available to national account members outside Plan service area?
-- REUSING existing column SRVC_NATIONAL_ACCOUNT_MEMBERS to store Y/N value.
-- Old records contain free text - viewable as legacy data.
-- ----------------------------------------------------------------------------

-- ----------------------------------------------------------------------------
-- Q15: What do the services entail? (open text)
-- REUSING existing column SRVC_SERVICES_ENTAIL.
-- Same semantic meaning - no change.
-- ----------------------------------------------------------------------------

-- ----------------------------------------------------------------------------
-- Q16: Outreach to providers outside Plan service area?
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q16_PROVIDER_OUTREACH_IND CHAR(1) NULL;
GO

-- ----------------------------------------------------------------------------
-- Q17: What does provider outreach entail? (open text)
-- ----------------------------------------------------------------------------
ALTER TABLE brand_request ADD CB_Q17_PROVIDER_OUTREACH_TXT VARCHAR(MAX) NULL;
GO

-- =============================================================================
-- Reference data update: enable "Other" as an IPP trigger
-- =============================================================================
-- The Q10-Q17 IPP block fires when a selected service category has
-- SRVC_CTGY_QUE_REQUIRED = 1. To make "Other" trigger IPP, run:
--
--   SELECT SRVC_CTGY_NM, SRVC_CTGY_QUE_REQUIRED FROM service_category;
--   -- verify current state, then:
--   UPDATE service_category SET SRVC_CTGY_QUE_REQUIRED = 1
--    WHERE SRVC_CTGY_NM = 'Other';
--
-- Confirm with the same SELECT before proceeding.

-- =============================================================================
-- Verify additions
-- =============================================================================
-- Run this to confirm all 22 new columns were added:
--
-- SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE
-- FROM INFORMATION_SCHEMA.COLUMNS
-- WHERE TABLE_NAME = 'brand_request'
--   AND COLUMN_NAME LIKE 'CB[_]Q%'
-- ORDER BY COLUMN_NAME;

-- =============================================================================
-- Rollback (if ever needed)
-- =============================================================================
-- ALTER TABLE brand_request DROP COLUMN CB_Q1_LEGAL_NAME_CNFRMD;
-- ALTER TABLE brand_request DROP COLUMN CB_Q2_DEBIT_CARD_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q2_LICENSE_AGMT_DT;
-- ALTER TABLE brand_request DROP COLUMN CB_Q3_CLIENT_LIST_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q3_EXCEPTION_ACK_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q4_BRAND_MISUSE_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q4_MISUSE_LINKS_TXT;
-- ALTER TABLE brand_request DROP COLUMN CB_Q4_MISUSE_CONTACT_TXT;
-- ALTER TABLE brand_request DROP COLUMN CB_Q4_MISUSE_ACK_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q5_NAME_LOGO_INFRNG_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q5_INFRNG_LINKS_TXT;
-- ALTER TABLE brand_request DROP COLUMN CB_Q5_INFRNG_CONTACT_TXT;
-- ALTER TABLE brand_request DROP COLUMN CB_Q5_INFRNG_ACK_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q6_FINL_STABLE_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q7_FELONY_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q8_NOT_ON_LIST_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q9_REPUTATION_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q10_INTER_PLAN_EXEC_TXT;
-- ALTER TABLE brand_request DROP COLUMN CB_Q11_OTHER_TXT;
-- ALTER TABLE brand_request DROP COLUMN CB_Q12_TELEHEALTH_SVC_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q13_VIRTUAL_ONLY_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q16_PROVIDER_OUTREACH_IND;
-- ALTER TABLE brand_request DROP COLUMN CB_Q17_PROVIDER_OUTREACH_TXT;
-- GO
