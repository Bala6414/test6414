-- =============================================================================
-- BlueWeb Co-Branding Partner Form Enhancement
-- DDL: Enable "Other" service category to trigger Inter-Plan Policy questions
-- =============================================================================
-- Purpose:
--   The Q10-Q17 IPP question block fires when a selected service category has
--   SRVC_CTGY_QUE_REQUIRED = 1. This script flips that flag for the "Other"
--   service category so that selecting it on the form triggers IPP questions.
--
-- Run order:
--   1. Run after 01_alter_brand_request_add_questions.sql
--   2. Run against DEV first, then QA, then PROD
-- =============================================================================

-- USE [your_database_name];
-- GO

-- ----------------------------------------------------------------------------
-- Step 1: Verify current state (what's there before the change)
-- ----------------------------------------------------------------------------
SELECT SRVC_CTGY_NM, SRVC_CTGY_QUE_REQUIRED
FROM service_category
ORDER BY SRVC_CTGY_NM;
GO

-- ----------------------------------------------------------------------------
-- Step 2: Apply the update
-- ----------------------------------------------------------------------------
UPDATE service_category
SET SRVC_CTGY_QUE_REQUIRED = 1
WHERE SRVC_CTGY_NM = 'Other';
GO

-- ----------------------------------------------------------------------------
-- Step 3: Confirm the update (the "Other" row should now show 1)
-- ----------------------------------------------------------------------------
SELECT SRVC_CTGY_NM, SRVC_CTGY_QUE_REQUIRED
FROM service_category
WHERE SRVC_CTGY_NM = 'Other';
GO

-- =============================================================================
-- Rollback (if ever needed)
-- =============================================================================
-- UPDATE service_category
-- SET SRVC_CTGY_QUE_REQUIRED = 0
-- WHERE SRVC_CTGY_NM = 'Other';
-- GO
